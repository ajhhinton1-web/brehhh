"""Server configuration: the /setup wizard, /config commands and /funadmin.

Everything here needs the Manage Server permission.
"""

from typing import TYPE_CHECKING, List, Optional

import discord
from discord import app_commands
from discord.ext import commands

from cogs.economy import ConfirmView
from database import ADMIN_GROUPS, AMOUNTS, MODULES, GuildSettings

if TYPE_CHECKING:
    from bot import AdminBot

# Permissions the bot needs for every feature to work.
REQUIRED_PERMISSIONS = [
    "view_channel", "send_messages", "embed_links", "read_message_history", "manage_messages",
    "kick_members", "ban_members", "moderate_members", "manage_channels", "manage_roles",
]


def pretty_permission(name: str) -> str:
    return name.replace("_", " ").title()


def health_check(guild: discord.Guild) -> List[str]:
    """Things that would stop the bot working properly in this server."""
    problems = []
    perms = guild.me.guild_permissions
    if not perms.administrator:
        missing = [p for p in REQUIRED_PERMISSIONS if not getattr(perms, p)]
        if missing:
            problems.append("I'm missing: " + ", ".join(f"**{pretty_permission(p)}**" for p in missing))
    above = [r for r in guild.roles if r > guild.me.top_role and not r.managed]
    if above:
        problems.append(
            f"{len(above)} role(s) are above mine, so I can't moderate anyone who has them. "
            "Drag my role higher in Server Settings → Roles."
        )
    return problems


def channel_problem(guild: discord.Guild, channel_id: int) -> Optional[str]:
    channel = guild.get_channel(channel_id)
    if channel is None:
        return "I can't see that channel."
    perms = channel.permissions_for(guild.me)
    if not (perms.view_channel and perms.send_messages and perms.embed_links):
        return f"I need View Channel, Send Messages and Embed Links in {channel.mention}."
    return None


def settings_embed(guild: discord.Guild, s: GuildSettings, log_channel_id: Optional[int], title: Optional[str] = None) -> discord.Embed:
    embed = discord.Embed(title=title or f"⚙️ Settings for {guild.name}", colour=discord.Colour.blurple())
    embed.add_field(name="📝 Mod-log channel", value=f"<#{log_channel_id}>" if log_channel_id else "Off")
    embed.add_field(name="🎮 Games channel", value=f"<#{s.games_channel_id}>" if s.games_channel_id else "Anywhere")
    embed.add_field(
        name="Modules",
        value="\n".join(f"{'✅' if getattr(s, key) else '❌'} {label}" for key, label in MODULES.items()),
        inline=False,
    )
    embed.add_field(
        name="Amounts",
        value="\n".join(f"{label}: **{getattr(s, key):,}**" for key, (label, _, _) in AMOUNTS.items()),
        inline=False,
    )
    if s.disabled_commands:
        embed.add_field(name="Disabled commands", value=", ".join(f"`/{c}`" for c in s.disabled_commands), inline=False)
    return embed


# ============================================================ setup wizard


class AmountsModal(discord.ui.Modal, title="Economy amounts"):
    def __init__(self, wizard: "SetupWizard") -> None:
        super().__init__()
        self.wizard = wizard
        self.inputs = {}
        for key, (label, low, high) in AMOUNTS.items():
            field = discord.ui.TextInput(
                label=f"{label} ({low:,}-{high:,})",
                default=str(getattr(wizard.draft, key)),
                max_length=9,
            )
            self.inputs[key] = field
            self.add_item(field)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        values, errors = {}, []
        for key, field in self.inputs.items():
            label, low, high = AMOUNTS[key]
            text = field.value.strip().replace(",", "")
            if not text.isdigit() or not low <= int(text) <= high:
                errors.append(f"**{label}** must be a whole number from {low:,} to {high:,}.")
            else:
                values[key] = int(text)
        if not errors and values["work_min"] > values["work_max"]:
            errors.append("**Work pay (min)** can't be bigger than **Work pay (max)**.")
        if errors:
            return await interaction.response.send_message("\n".join(errors), ephemeral=True)
        for key, value in values.items():
            setattr(self.wizard.draft, key, value)
        await self.wizard.refresh(interaction)


class SetupWizard(discord.ui.View):
    STEPS = ("welcome", "logs", "modules", "games", "amounts", "review")

    def __init__(self, cog: "Config", admin: discord.abc.User, guild: discord.Guild, settings: GuildSettings, log_channel_id: Optional[int]) -> None:
        super().__init__(timeout=600)
        self.cog = cog
        self.admin = admin
        self.guild = guild
        self.draft = settings
        self.log_channel_id = log_channel_id
        self.step = 0
        self.note: Optional[str] = None  # warning shown once on the next screen
        self.message: Optional[discord.InteractionMessage] = None
        self.build()

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.admin.id

    # ---------------------------------------------------------- screens

    def render(self) -> discord.Embed:
        step = self.STEPS[self.step]
        progress = f"Step {self.step} of {len(self.STEPS) - 1}" if self.step else "Setup wizard"
        embed = discord.Embed(colour=discord.Colour.blurple())
        embed.set_author(name=progress)

        if step == "welcome":
            embed.title = f"👋 Let's set up {self.cog.bot.user.name if self.cog.bot.user else 'the bot'}!"
            embed.description = (
                "This takes about a minute. You'll choose:\n"
                "1️⃣ A **mod-log** channel\n2️⃣ Which **features** are on\n"
                "3️⃣ An optional **games channel**\n4️⃣ **Economy amounts**\n\n"
                "Nothing is saved until the last step, and you can run `/setup` again any time."
            )
        elif step == "logs":
            embed.title = "📝 Mod-log channel"
            embed.description = (
                "Where should I post moderation actions, deleted/edited messages and joins/leaves?\n"
                "Pick a channel below. A private staff channel works best.\n\n"
                f"**Current choice:** {f'<#{self.log_channel_id}>' if self.log_channel_id else 'Off'}"
            )
        elif step == "modules":
            embed.title = "🧩 Features"
            embed.description = (
                "Click to switch features on or off. Moderation is always on.\n"
                "You can also disable single commands later with `/config command`."
            )
        elif step == "games":
            embed.title = "🎮 Games channel"
            embed.description = (
                "Want economy, fun and battle commands to only work in one channel (like #bot-commands)? "
                "Pick it below, or allow them everywhere. Admins can use them anywhere.\n\n"
                f"**Current choice:** {f'<#{self.draft.games_channel_id}>' if self.draft.games_channel_id else 'Anywhere'}"
            )
        elif step == "amounts":
            embed.title = "💰 Economy amounts"
            embed.description = "These are the defaults. Click **Edit amounts** to change them.\n\n" + "\n".join(
                f"{label}: **{getattr(self.draft, key):,}** 🪙" for key, (label, _, _) in AMOUNTS.items()
            )
        else:  # review
            embed = settings_embed(self.guild, self.draft, self.log_channel_id, title="✅ Review and save")
            embed.set_author(name=progress)
            problems = health_check(self.guild)
            embed.add_field(
                name="🩺 Health check",
                value="\n".join(f"⚠️ {p}" for p in problems) if problems else "All permissions look good!",
                inline=False,
            )
            embed.set_footer(text="Click Save to apply these settings.")

        if self.note:
            embed.add_field(name="⚠️ Heads up", value=self.note, inline=False)
            self.note = None
        return embed

    def build(self) -> None:
        """Rebuild the buttons/menus for the current step."""
        self.clear_items()
        step = self.STEPS[self.step]

        if step == "logs":
            select = discord.ui.ChannelSelect(channel_types=[discord.ChannelType.text], placeholder="Pick the mod-log channel…", row=0)
            select.callback = self._pick_log_channel(select)
            self.add_item(select)
            self._button("Turn logging off", discord.ButtonStyle.secondary, self._logging_off, row=1)

        elif step == "modules":
            for i, (key, label) in enumerate(MODULES.items()):
                on = getattr(self.draft, key)
                self._button(
                    label.split(" (")[0],  # keep button text short
                    discord.ButtonStyle.success if on else discord.ButtonStyle.secondary,
                    self._toggle(key),
                    emoji="✅" if on else "❌",
                    row=i // 3,
                )

        elif step == "games":
            select = discord.ui.ChannelSelect(channel_types=[discord.ChannelType.text], placeholder="Pick a games channel…", row=0)
            select.callback = self._pick_games_channel(select)
            self.add_item(select)
            self._button("Allow everywhere", discord.ButtonStyle.secondary, self._games_anywhere, row=1)

        elif step == "amounts":
            self._button("Edit amounts", discord.ButtonStyle.primary, self._edit_amounts, emoji="✏️", row=0)

        # navigation row
        if step == "welcome":
            self._button("Start", discord.ButtonStyle.success, self._next, emoji="▶️", row=4)
        else:
            self._button("Back", discord.ButtonStyle.secondary, self._back, emoji="◀️", row=4)
            if step == "review":
                self._button("Save", discord.ButtonStyle.success, self._save, emoji="💾", row=4)
            else:
                self._button("Next", discord.ButtonStyle.primary, self._next, emoji="▶️", row=4)
        self._button("Cancel", discord.ButtonStyle.danger, self._cancel, row=4)

    def _button(self, label, style, callback, *, emoji=None, row=None) -> None:
        button = discord.ui.Button(label=label, style=style, emoji=emoji, row=row)
        button.callback = callback
        self.add_item(button)

    async def refresh(self, interaction: discord.Interaction) -> None:
        self.build()
        await interaction.response.edit_message(embed=self.render(), view=self)

    # ---------------------------------------------------------- actions

    async def _next(self, interaction: discord.Interaction) -> None:
        self.step = min(self.step + 1, len(self.STEPS) - 1)
        await self.refresh(interaction)

    async def _back(self, interaction: discord.Interaction) -> None:
        self.step = max(self.step - 1, 0)
        await self.refresh(interaction)

    def _pick_log_channel(self, select: discord.ui.ChannelSelect):
        async def callback(interaction: discord.Interaction) -> None:
            channel_id = select.values[0].id
            problem = channel_problem(self.guild, channel_id)
            if problem:
                self.note = problem
            else:
                self.log_channel_id = channel_id
            await self.refresh(interaction)
        return callback

    async def _logging_off(self, interaction: discord.Interaction) -> None:
        self.log_channel_id = None
        await self.refresh(interaction)

    def _toggle(self, key: str):
        async def callback(interaction: discord.Interaction) -> None:
            setattr(self.draft, key, not getattr(self.draft, key))
            await self.refresh(interaction)
        return callback

    def _pick_games_channel(self, select: discord.ui.ChannelSelect):
        async def callback(interaction: discord.Interaction) -> None:
            channel_id = select.values[0].id
            problem = channel_problem(self.guild, channel_id)
            if problem:
                self.note = problem
            else:
                self.draft.games_channel_id = channel_id
            await self.refresh(interaction)
        return callback

    async def _games_anywhere(self, interaction: discord.Interaction) -> None:
        self.draft.games_channel_id = None
        await self.refresh(interaction)

    async def _edit_amounts(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_modal(AmountsModal(self))

    async def _save(self, interaction: discord.Interaction) -> None:
        self.stop()
        db = self.cog.bot.db
        await db.save_settings(self.guild.id, self.draft)
        await db.set_log_channel(self.guild.id, self.log_channel_id)
        embed = settings_embed(self.guild, self.draft, self.log_channel_id, title="🎉 Setup complete!")
        embed.set_footer(text="Change anything later with /config or run /setup again.")
        await interaction.response.edit_message(embed=embed, view=None)

        if self.log_channel_id:
            channel = self.guild.get_channel(self.log_channel_id)
            if isinstance(channel, discord.TextChannel):
                try:
                    await channel.send(embed=discord.Embed(
                        description=f"✅ Setup completed by {interaction.user.mention}. Mod logs will appear here.",
                        colour=discord.Colour.green(),
                    ))
                except discord.HTTPException:
                    pass

    async def _cancel(self, interaction: discord.Interaction) -> None:
        self.stop()
        await interaction.response.edit_message(
            embed=discord.Embed(description="Setup cancelled. Nothing was changed.", colour=discord.Colour.greyple()), view=None
        )

    async def on_timeout(self) -> None:
        if self.message is not None:
            try:
                await self.message.edit(
                    embed=discord.Embed(description="⌛ Setup timed out. Nothing was saved. Run `/setup` to start again.", colour=discord.Colour.greyple()),
                    view=None,
                )
            except discord.HTTPException:
                pass


# ===================================================================== cog


class Config(commands.Cog):
    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    def game_commands(self) -> List[str]:
        """Top-level game commands that /config command can switch off."""
        names = []
        for cog in self.bot.cogs.values():
            if getattr(cog, "MODULE", None):
                names.extend(c.name for c in cog.get_app_commands() if c.name not in ADMIN_GROUPS)
        return sorted(names)

    @commands.Cog.listener()
    async def on_guild_join(self, guild: discord.Guild) -> None:
        channel = guild.system_channel
        if channel is None or not channel.permissions_for(guild.me).send_messages:
            return
        try:
            await channel.send(embed=discord.Embed(
                title="👋 Thanks for adding me!",
                description="An admin should run **`/setup`** to pick a log channel and choose which features are on.",
                colour=discord.Colour.blurple(),
            ))
        except discord.HTTPException:
            pass

    # ================================================================ /setup

    @app_commands.command(name="setup", description="Step-by-step wizard to set the bot up for this server.")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setup(self, interaction: discord.Interaction) -> None:
        settings = await self.db.get_settings(interaction.guild_id)
        log_channel_id = await self.db.get_log_channel(interaction.guild_id)
        wizard = SetupWizard(self, interaction.user, interaction.guild, settings, log_channel_id)
        await interaction.response.send_message(embed=wizard.render(), view=wizard, ephemeral=True)
        wizard.message = await interaction.original_response()

    # =============================================================== /config

    config = app_commands.Group(
        name="config",
        description="Change the bot's settings for this server.",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    @config.command(name="view", description="Show all current settings.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_view(self, interaction: discord.Interaction) -> None:
        settings = await self.db.get_settings(interaction.guild_id)
        embed = settings_embed(interaction.guild, settings, await self.db.get_log_channel(interaction.guild_id))
        problems = health_check(interaction.guild)
        if problems:
            embed.add_field(name="🩺 Health check", value="\n".join(f"⚠️ {p}" for p in problems), inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @config.command(name="module", description="Switch a whole feature on or off.")
    @app_commands.describe(module="Which feature", enabled="On or off")
    @app_commands.choices(module=[app_commands.Choice(name=label, value=key) for key, label in MODULES.items()])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_module(self, interaction: discord.Interaction, module: str, enabled: bool) -> None:
        settings = await self.db.get_settings(interaction.guild_id)
        setattr(settings, module, enabled)
        await self.db.save_settings(interaction.guild_id, settings)
        await interaction.response.send_message(f"{'✅' if enabled else '❌'} {MODULES[module]} is now **{'on' if enabled else 'off'}**.")

    @config.command(name="command", description="Switch a single game command on or off.")
    @app_commands.describe(command="Which command (e.g. rob, slots, ship)", enabled="On or off")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_command(self, interaction: discord.Interaction, command: str, enabled: bool) -> None:
        name = command.strip().lstrip("/").split(" ")[0].lower()
        if name not in self.game_commands():
            return await interaction.response.send_message(
                f"`/{name}` isn't a game command. Moderation and admin commands can't be disabled this way.", ephemeral=True
            )
        settings = await self.db.get_settings(interaction.guild_id)
        disabled = set(settings.disabled_commands)
        if enabled:
            disabled.discard(name)
        else:
            disabled.add(name)
        settings.disabled_commands = sorted(disabled)
        await self.db.save_settings(interaction.guild_id, settings)
        await interaction.response.send_message(f"{'✅' if enabled else '🚫'} `/{name}` is now **{'enabled' if enabled else 'disabled'}**.")

    @config_command.autocomplete("command")
    async def config_command_autocomplete(self, interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
        current = current.lower().lstrip("/")
        return [app_commands.Choice(name=f"/{n}", value=n) for n in self.game_commands() if current in n][:25]

    @config.command(name="gameschannel", description="Only allow game commands in one channel (leave empty for anywhere).")
    @app_commands.describe(channel="The games channel, or leave empty to allow everywhere")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_gameschannel(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        settings = await self.db.get_settings(interaction.guild_id)
        if channel is not None and (problem := channel_problem(interaction.guild, channel.id)):
            return await interaction.response.send_message(problem, ephemeral=True)
        settings.games_channel_id = channel.id if channel else None
        await self.db.save_settings(interaction.guild_id, settings)
        where = channel.mention if channel else "any channel"
        await interaction.response.send_message(f"🎮 Game commands now work in {where}.")

    @config.command(name="amount", description="Change a reward amount (daily, work pay, trivia, battles).")
    @app_commands.describe(setting="What to change", value="New amount")
    @app_commands.choices(setting=[app_commands.Choice(name=label, value=key) for key, (label, _, _) in AMOUNTS.items()])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_amount(self, interaction: discord.Interaction, setting: str, value: int) -> None:
        label, low, high = AMOUNTS[setting]
        if not low <= value <= high:
            return await interaction.response.send_message(f"**{label}** must be between {low:,} and {high:,}.", ephemeral=True)
        settings = await self.db.get_settings(interaction.guild_id)
        setattr(settings, setting, value)
        if settings.work_min > settings.work_max:
            return await interaction.response.send_message("Work pay (min) can't be bigger than Work pay (max).", ephemeral=True)
        await self.db.save_settings(interaction.guild_id, settings)
        await interaction.response.send_message(f"💰 **{label}** is now **{value:,}** 🪙")

    @config.command(name="reset", description="Put every setting back to its default. Asks for confirmation.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def config_reset(self, interaction: discord.Interaction) -> None:
        async def do_reset(button_interaction: discord.Interaction) -> None:
            await self.db.save_settings(interaction.guild_id, GuildSettings())
            await button_interaction.response.edit_message(content="♻️ All settings are back to their defaults. (The log channel wasn't changed.)", view=None)

        await interaction.response.send_message(
            "Reset modules, games channel, disabled commands and amounts to defaults?",
            view=ConfirmView(interaction.user.id, do_reset),
            ephemeral=True,
        )

    # ============================================================= /funadmin

    funadmin = app_commands.Group(
        name="funadmin",
        description="Add your own trivia questions and jokes.",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    @funadmin.command(name="addtrivia", description="Add a trivia question for this server.")
    @app_commands.describe(question="The question", correct="The right answer", wrong1="A wrong answer", wrong2="Another wrong answer", wrong3="Another wrong answer")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def funadmin_addtrivia(
        self,
        interaction: discord.Interaction,
        question: app_commands.Range[str, 5, 250],
        correct: app_commands.Range[str, 1, 80],
        wrong1: app_commands.Range[str, 1, 80],
        wrong2: app_commands.Range[str, 1, 80],
        wrong3: app_commands.Range[str, 1, 80],
    ) -> None:
        answers = [correct, wrong1, wrong2, wrong3]
        if len({a.strip().lower() for a in answers}) < 4:
            return await interaction.response.send_message("All four answers need to be different.", ephemeral=True)
        new_id = await self.db.add_content(
            interaction.guild_id, "trivia", {"question": question, "correct": correct, "wrong": [wrong1, wrong2, wrong3]}
        )
        await interaction.response.send_message(f"🧠 Added trivia question **#{new_id}**. It'll now come up in `/trivia`.", ephemeral=True)

    @funadmin.command(name="addjoke", description="Add a joke for /joke in this server.")
    @app_commands.describe(text="The joke")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def funadmin_addjoke(self, interaction: discord.Interaction, text: app_commands.Range[str, 5, 500]) -> None:
        new_id = await self.db.add_content(interaction.guild_id, "joke", {"text": text})
        await interaction.response.send_message(f"😂 Added joke **#{new_id}**.", ephemeral=True)

    @funadmin.command(name="list", description="See the custom trivia and jokes you've added.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def funadmin_list(self, interaction: discord.Interaction) -> None:
        items = await self.db.list_content(interaction.guild_id)
        if not items:
            return await interaction.response.send_message("No custom content yet. Add some with `/funadmin addtrivia` or `/funadmin addjoke`.", ephemeral=True)
        lines = []
        for item in items:
            text = item["question"] if item["kind"] == "trivia" else item["text"]
            icon = "🧠" if item["kind"] == "trivia" else "😂"
            lines.append(f"`#{item['id']}` {icon} {text[:80]}{'…' if len(text) > 80 else ''}")
        description = "\n".join(lines)
        if len(description) > 4000:
            description = description[:4000].rsplit("\n", 1)[0] + "\n…and more"
        embed = discord.Embed(title="Custom fun content", description=description, colour=discord.Colour.purple())
        embed.set_footer(text="Remove one with /funadmin remove")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @funadmin.command(name="remove", description="Remove a custom trivia question or joke by its number.")
    @app_commands.describe(number="The # shown in /funadmin list")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def funadmin_remove(self, interaction: discord.Interaction, number: int) -> None:
        if await self.db.delete_content(interaction.guild_id, number):
            await interaction.response.send_message(f"🗑️ Removed #{number}.", ephemeral=True)
        else:
            await interaction.response.send_message(f"There's no custom item #{number} in this server.", ephemeral=True)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Config(bot))