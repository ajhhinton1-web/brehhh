"""Fun commands: trivia (pays coins), 8ball, dice, polls, rock-paper-scissors and more."""

import random
import re
from datetime import timedelta
from typing import TYPE_CHECKING, List, Literal, Optional

import discord
from discord import app_commands
from discord.ext import commands

if TYPE_CHECKING:
    from bot import AdminBot

TRIVIA_TIME_LIMIT = 20  # seconds
# The trivia coin reward is set per server with /setup or /config amount.
# Admins can add their own questions and jokes with /funadmin.

# (question, correct answer, three wrong answers)
TRIVIA = [
    ("What is the largest planet in our solar system?", "Jupiter", ["Saturn", "Neptune", "Earth"]),
    ("How many continents are there?", "7", ["5", "6", "8"]),
    ("Which gas do plants absorb from the air?", "Carbon dioxide", ["Oxygen", "Nitrogen", "Helium"]),
    ("What is the chemical symbol for gold?", "Au", ["Ag", "Gd", "Go"]),
    ("How many sides does a hexagon have?", "6", ["5", "7", "8"]),
    ("Which is the largest ocean on Earth?", "Pacific", ["Atlantic", "Indian", "Arctic"]),
    ("What is the capital of Japan?", "Tokyo", ["Kyoto", "Osaka", "Seoul"]),
    ("How many bones are in the adult human body?", "206", ["201", "212", "186"]),
    ("What is the fastest land animal?", "Cheetah", ["Lion", "Pronghorn", "Greyhound"]),
    ("In what year did the Titanic sink?", "1912", ["1905", "1921", "1898"]),
    ("What is the hardest natural substance?", "Diamond", ["Quartz", "Titanium", "Granite"]),
    ("Which planet is known as the Red Planet?", "Mars", ["Venus", "Mercury", "Jupiter"]),
    ("At what temperature does water freeze in Fahrenheit?", "32°F", ["0°F", "100°F", "212°F"]),
    ("Who painted the Mona Lisa?", "Leonardo da Vinci", ["Michelangelo", "Raphael", "Vincent van Gogh"]),
    ("What is the smallest prime number?", "2", ["1", "3", "0"]),
    ("How many minutes are in a full day?", "1,440", ["1,240", "1,400", "2,440"]),
    ("Which element has the chemical symbol O?", "Oxygen", ["Osmium", "Gold", "Oganesson"]),
    ("How many players are on a football (soccer) team on the pitch?", "11", ["10", "9", "12"]),
    ("What is the longest bone in the human body?", "Femur", ["Tibia", "Humerus", "Spine"]),
    ("Which country has the most people?", "India", ["China", "USA", "Indonesia"]),
]

EIGHT_BALL = [
    "Absolutely.", "Without a doubt.", "The stars say yes.", "Looks good to me.", "Yes — go for it.",
    "Signs point to yes.", "Ask me again after a snack.", "The vibes are unclear.", "I'd rather not say.",
    "Hmm, concentrate and ask again.", "Don't count on it.", "My sources say nope.",
    "Very doubtful.", "Absolutely not.", "That's a no from me.",
]

JOKES = [
    "Why don't skeletons fight each other? They don't have the guts.",
    "I told my computer I needed a break, and it said: 'No problem, I'll go to sleep.'",
    "Why did the scarecrow win an award? He was outstanding in his field.",
    "What do you call fake spaghetti? An impasta.",
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "I'm reading a book about anti-gravity. It's impossible to put down.",
    "Why did the bicycle fall over? It was two-tired.",
    "What do you call a bear with no teeth? A gummy bear.",
    "Why can't you trust atoms? They make up everything.",
    "Parallel lines have so much in common. It's a shame they'll never meet.",
    "Why did the Discord mod bring a ladder? To reach the higher roles.",
    "What's orange and sounds like a parrot? A carrot.",
    "I only know 25 letters of the alphabet. I don't know y.",
    "Why was the maths book sad? It had too many problems.",
    "How do you organise a space party? You planet.",
    "What did the ocean say to the beach? Nothing, it just waved.",
    "Why don't eggs tell jokes? They'd crack each other up.",
    "My Wi-Fi went down for five minutes, so I had to talk to my family. They seem like nice people.",
]

NUMBER_EMOJI = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
DICE_PATTERN = re.compile(r"^(\d*)d(\d+)([+-]\d+)?$")
RPS_BEATS = {"rock": "scissors", "paper": "rock", "scissors": "paper"}
RPS_EMOJI = {"rock": "🪨", "paper": "📄", "scissors": "✂️"}


def stable_percent(*parts: object) -> int:
    """Same inputs always give the same 0-100 result (so /ship and /rate don't change each time)."""
    return random.Random("|".join(str(p) for p in parts)).randint(0, 100)


class TriviaView(discord.ui.View):
    def __init__(self, bot: "AdminBot", player: discord.abc.User, guild_id: int, answers: List[str], correct: int, reward: int) -> None:
        super().__init__(timeout=TRIVIA_TIME_LIMIT)
        self.bot = bot
        self.reward = reward
        self.player = player
        self.guild_id = guild_id
        self.answers = answers
        self.correct = correct
        self.message: Optional[discord.InteractionMessage] = None

        for index, answer in enumerate(answers):
            button = discord.ui.Button(label=answer, style=discord.ButtonStyle.secondary)
            button.callback = self._make_callback(index)
            self.add_item(button)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.player.id:
            await interaction.response.send_message("This isn't your question. Use `/trivia` to get your own!", ephemeral=True)
            return False
        return True

    def _reveal(self, chosen: Optional[int]) -> None:
        for index, child in enumerate(self.children):
            child.disabled = True
            if index == self.correct:
                child.style = discord.ButtonStyle.success
            elif index == chosen:
                child.style = discord.ButtonStyle.danger

    def _make_callback(self, index: int):
        async def callback(interaction: discord.Interaction) -> None:
            self.stop()
            self._reveal(index)
            if index == self.correct:
                result = f"✅ Correct, {self.player.mention}!"
                if self.reward:
                    await self.bot.db.add_wallet(self.guild_id, self.player.id, self.reward)
                    result += f" You earned **{self.reward:,}** 🪙"
            else:
                result = f"❌ Wrong! The answer was **{self.answers[self.correct]}**."
            await interaction.response.edit_message(content=result, view=self)

        return callback

    async def on_timeout(self) -> None:
        self._reveal(None)
        if self.message is not None:
            try:
                await self.message.edit(content=f"⏰ Time's up! The answer was **{self.answers[self.correct]}**.", view=self)
            except discord.HTTPException:
                pass


class Fun(commands.Cog):
    MODULE = "fun"  # can be switched off per server with /config module

    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    @app_commands.command(name="trivia", description="Answer a trivia question to win coins.")
    @app_commands.guild_only()
    @app_commands.checks.cooldown(1, 15)  # once every 15s per user, so it can't be spammed for coins
    async def trivia(self, interaction: discord.Interaction) -> None:
        custom = await self.bot.db.list_content(interaction.guild_id, "trivia")
        pool = TRIVIA + [(q["question"], q["correct"], q["wrong"]) for q in custom]
        question, correct, wrong = random.choice(pool)
        answers = [correct, *wrong]
        random.shuffle(answers)
        settings = await self.bot.db.get_settings(interaction.guild_id)
        reward = settings.trivia_reward if settings.economy else 0
        view = TriviaView(self.bot, interaction.user, interaction.guild_id, answers, answers.index(correct), reward)

        embed = discord.Embed(title="🧠 Trivia", description=f"**{question}**", colour=discord.Colour.purple())
        embed.set_footer(text=f"You have {TRIVIA_TIME_LIMIT} seconds")
        await interaction.response.send_message(embed=embed, view=view)
        view.message = await interaction.original_response()

    @app_commands.command(name="8ball", description="Ask the magic 8-ball a yes/no question.")
    @app_commands.describe(question="Your question")
    async def eightball(self, interaction: discord.Interaction, question: app_commands.Range[str, 1, 200]) -> None:
        await interaction.response.send_message(f"❓ {question}\n🎱 {random.choice(EIGHT_BALL)}")

    @app_commands.command(name="coinflip", description="Flip a coin.")
    async def coinflip(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(f"🪙 **{random.choice(['Heads', 'Tails'])}!**")

    @app_commands.command(name="roll", description="Roll dice, e.g. d20, 2d6 or 3d8+2.")
    @app_commands.describe(dice="Dice to roll (default d6)")
    async def roll(self, interaction: discord.Interaction, dice: str = "d6") -> None:
        match = DICE_PATTERN.match(dice.lower().replace(" ", ""))
        if not match:
            return await interaction.response.send_message("Use a format like `d20`, `2d6` or `3d8+2`.", ephemeral=True)
        count = int(match.group(1) or 1)
        sides = int(match.group(2))
        modifier = int(match.group(3) or 0)
        if not (1 <= count <= 25 and 2 <= sides <= 1000):
            return await interaction.response.send_message("You can roll 1-25 dice with 2-1000 sides.", ephemeral=True)

        rolls = [random.randint(1, sides) for _ in range(count)]
        total = sum(rolls) + modifier
        detail = ", ".join(map(str, rolls))
        if modifier:
            detail += f" ({modifier:+d})"
        await interaction.response.send_message(f"🎲 `{dice}` → **{total}**" + (f"  [{detail}]" if count > 1 or modifier else ""))

    @app_commands.command(name="rps", description="Play rock, paper, scissors against me.")
    @app_commands.describe(choice="Your move")
    async def rps(self, interaction: discord.Interaction, choice: Literal["rock", "paper", "scissors"]) -> None:
        mine = random.choice(list(RPS_BEATS))
        if mine == choice:
            outcome = "It's a draw! 🤝"
        elif RPS_BEATS[choice] == mine:
            outcome = "You win! 🎉"
        else:
            outcome = "I win! 😎"
        await interaction.response.send_message(f"You: {RPS_EMOJI[choice]}  vs  Me: {RPS_EMOJI[mine]}\n**{outcome}**")

    @app_commands.command(name="choose", description="Can't decide? I'll pick for you.")
    @app_commands.describe(options="Options separated by commas, e.g. pizza, tacos, sushi")
    async def choose(self, interaction: discord.Interaction, options: str) -> None:
        choices = [o.strip() for o in options.split(",") if o.strip()]
        if len(choices) < 2:
            return await interaction.response.send_message("Give me at least two options, separated by commas.", ephemeral=True)
        await interaction.response.send_message(f"🤔 I choose... **{random.choice(choices)}**!")

    @app_commands.command(name="joke", description="Hear a (bad) joke.")
    async def joke(self, interaction: discord.Interaction) -> None:
        custom = await self.bot.db.list_content(interaction.guild_id, "joke") if interaction.guild_id else []
        await interaction.response.send_message(f"😂 {random.choice(JOKES + [j['text'] for j in custom])}")

    @app_commands.command(name="ship", description="How compatible are two members?")
    @app_commands.describe(first="First person", second="Second person (defaults to you)")
    @app_commands.guild_only()
    async def ship(self, interaction: discord.Interaction, first: discord.Member, second: Optional[discord.Member] = None) -> None:
        second = second or interaction.user
        a, b = sorted((first.id, second.id))
        score = stable_percent("ship", a, b)
        hearts = round(score / 10)
        bar = "❤️" * hearts + "🖤" * (10 - hearts)
        if score >= 90:
            verdict = "Soulmates! 💍"
        elif score >= 70:
            verdict = "A great match! 💕"
        elif score >= 40:
            verdict = "Could work... 🤔"
        else:
            verdict = "Better as friends. 😬"
        await interaction.response.send_message(
            f"💘 **{first.display_name}** × **{second.display_name}**\n{bar} **{score}%**\n{verdict}",
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @app_commands.command(name="rate", description="I'll rate anything out of 10.")
    @app_commands.describe(thing="What should I rate?")
    async def rate(self, interaction: discord.Interaction, thing: app_commands.Range[str, 1, 100]) -> None:
        score = round(stable_percent("rate", thing.lower().strip()) / 10)
        await interaction.response.send_message(
            f"I'd rate **{thing}** a **{score}/10**.", allowed_mentions=discord.AllowedMentions.none()
        )

    @app_commands.command(name="avatar", description="Show someone's profile picture in full size.")
    @app_commands.describe(member="Whose avatar (defaults to you)")
    @app_commands.guild_only()
    async def avatar(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        member = member or interaction.user
        embed = discord.Embed(title=f"{member.display_name}'s avatar", colour=member.colour)
        embed.set_image(url=member.display_avatar.with_size(1024).url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="poll", description="Start a poll using Discord's built-in poll feature.")
    @app_commands.describe(
        question="What are you asking?",
        options="Answers separated by | e.g. Yes | No | Maybe (2-10 answers)",
        hours="How long it runs, in hours (default 24)",
        multiple="Let people pick more than one answer",
    )
    @app_commands.guild_only()
    async def poll(
        self,
        interaction: discord.Interaction,
        question: app_commands.Range[str, 1, 300],
        options: str,
        hours: app_commands.Range[int, 1, 168] = 24,
        multiple: bool = False,
    ) -> None:
        answers = [o.strip() for o in options.split("|") if o.strip()]
        if not 2 <= len(answers) <= 10:
            return await interaction.response.send_message("A poll needs 2-10 answers, separated by `|`.", ephemeral=True)
        if any(len(a) > 55 for a in answers):
            return await interaction.response.send_message("Each answer can be at most 55 characters.", ephemeral=True)

        poll = discord.Poll(question=question, duration=timedelta(hours=hours), multiple=multiple)
        for emoji, answer in zip(NUMBER_EMOJI, answers):
            poll.add_answer(text=answer, emoji=emoji)
        await interaction.response.send_message(poll=poll)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Fun(bot))