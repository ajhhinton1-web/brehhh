"""Server setup and admin tools: log channel, roles, user/server info."""

from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils import truncate

if TYPE_CHECKING:
    from bot import AdminBot


def role_error(actor: discord.Member, role: discord.Role) -> Optional[str]:
    """Return why `actor` can't hand out / take away `role`, or None if they can."""
    guild = role.guild
    if role.is_default():
        return "That's the @everyone role — everybody has it."
    if role.managed:
        return "That role is managed by an integration (bot role, booster role, etc.) and can't be assigned."
    if actor.id != guild.owner_id and role >= actor.top_role:
        return "You can only manage roles below your own top role."
    if role >= guild.me.top_role:
        return "That role is above (or equal to) my top role. Move my role higher in Server Settings → Roles."
    return None


class Admin(commands.Cog):
    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    # ------------------------------------------------------------ log channel

    @app_commands.command(name="setlogchannel", description="Choose where moderation logs are posted.")
    @app_commands.describe(channel="Log channel — leave empty to turn logging off")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setlogchannel(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        if channel is None:
            await self.bot.db.set_log_channel(interaction.guild.id, None)
            return await interaction.response.send_message("📴 Mod logging turned off.", ephemeral=True)

        perms = channel.permissions_for(interaction.guild.me)
        if not (perms.view_channel and perms.send_messages and perms.embed_links):
            return await interaction.response.send_message(
                f"I need **View Channel**, **Send Messages** and **Embed Links** in {channel.mention}.", ephemeral=True
            )

        await self.bot.db.set_log_channel(interaction.guild.id, channel.id)
        await interaction.response.send_message(f"📝 Mod logs will now go to {channel.mention}.", ephemeral=True)
        await channel.send(
            embed=discord.Embed(
                description=f"✅ This channel is now the mod log (set by {interaction.user.mention}).",
                colour=discord.Colour.green(),
            )
        )

    # ------------------------------------------------------------------ roles

    role_group = app_commands.Group(
        name="role",
        description="Give or take away roles.",
        guild_only=True,
        default_permissions=discord.Permissions(manage_roles=True),
    )

    @role_group.command(name="add", description="Give a member a role.")
    @app_commands.describe(member="Who gets the role", role="Which role")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.checks.bot_has_permissions(manage_roles=True)
    async def role_add(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role) -> None:
        if error := role_error(interaction.user, role):
            return await interaction.response.send_message(error, ephemeral=True)
        if role in member.roles:
            return await interaction.response.send_message(f"{member.mention} already has {role.mention}.", ephemeral=True)

        await member.add_roles(role, reason=f"Added by {interaction.user}")
        await interaction.response.send_message(
            f"➕ Gave {role.mention} to {member.mention}.", allowed_mentions=discord.AllowedMentions.none()
        )

    @role_group.command(name="remove", description="Take a role away from a member.")
    @app_commands.describe(member="Who loses the role", role="Which role")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.checks.bot_has_permissions(manage_roles=True)
    async def role_remove(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role) -> None:
        if error := role_error(interaction.user, role):
            return await interaction.response.send_message(error, ephemeral=True)
        if role not in member.roles:
            return await interaction.response.send_message(f"{member.mention} doesn't have {role.mention}.", ephemeral=True)

        await member.remove_roles(role, reason=f"Removed by {interaction.user}")
        await interaction.response.send_message(
            f"➖ Removed {role.mention} from {member.mention}.", allowed_mentions=discord.AllowedMentions.none()
        )

    # ------------------------------------------------------------------- info

    @app_commands.command(name="userinfo", description="Show details about a member, including their warning count.")
    @app_commands.describe(member="Who to look up (defaults to you)")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def userinfo(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        member = member or interaction.user
        warning_count = await self.bot.db.count_warnings(interaction.guild.id, member.id)

        embed = discord.Embed(title=str(member), colour=member.colour if member.colour.value else discord.Colour.blurple())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="ID", value=f"`{member.id}`")
        embed.add_field(name="Nickname", value=member.nick or "—")
        embed.add_field(name="Bot", value="Yes" if member.bot else "No")
        embed.add_field(name="Account created", value=discord.utils.format_dt(member.created_at, "R"))
        if member.joined_at:
            embed.add_field(name="Joined server", value=discord.utils.format_dt(member.joined_at, "R"))
        embed.add_field(name="Warnings", value=str(warning_count))
        if member.is_timed_out():
            embed.add_field(name="Timed out until", value=discord.utils.format_dt(member.timed_out_until, "f"))

        roles = [r.mention for r in reversed(member.roles) if not r.is_default()]
        embed.add_field(
            name=f"Roles ({len(roles)})",
            value=truncate(" ".join(roles), 1024) if roles else "None",
            inline=False,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="serverinfo", description="Show details about this server.")
    @app_commands.guild_only()
    async def serverinfo(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        humans = sum(1 for m in guild.members if not m.bot)

        embed = discord.Embed(title=guild.name, colour=discord.Colour.blurple())
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner", value=f"<@{guild.owner_id}>")
        embed.add_field(name="Created", value=discord.utils.format_dt(guild.created_at, "R"))
        embed.add_field(name="Members", value=f"{guild.member_count} ({humans} humans)")
        embed.add_field(name="Text channels", value=str(len(guild.text_channels)))
        embed.add_field(name="Voice channels", value=str(len(guild.voice_channels)))
        embed.add_field(name="Roles", value=str(len(guild.roles) - 1))
        embed.add_field(name="Boosts", value=f"Level {guild.premium_tier} ({guild.premium_subscription_count or 0} boosts)")
        embed.set_footer(text=f"Server ID {guild.id}")
        await interaction.response.send_message(embed=embed)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Admin(bot))