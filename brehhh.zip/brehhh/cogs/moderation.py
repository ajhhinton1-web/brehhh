"""Kick, ban, timeout, warnings and purge."""

from datetime import timedelta
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils import action_embed, format_duration, hierarchy_error, parse_duration, truncate

if TYPE_CHECKING:
    from bot import AdminBot

Reason = app_commands.Range[str, 1, 400]
NO_REASON = "No reason provided"
MAX_TIMEOUT = timedelta(days=28)  # Discord's limit


def audit_reason(interaction: discord.Interaction, reason: str) -> str:
    """Reason shown in the server's audit log: who did it and why."""
    return f"{interaction.user} ({interaction.user.id}): {reason}"


async def try_dm(user: discord.abc.User, message: str) -> bool:
    """DM a user, ignoring failures (closed DMs, no shared server, etc.)."""
    try:
        await user.send(message)
        return True
    except discord.HTTPException:
        return False


class Moderation(commands.Cog):
    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    # ------------------------------------------------------------------ kick

    @app_commands.command(name="kick", description="Kick a member from the server.")
    @app_commands.describe(member="Who to kick", reason="Why (shown in the audit log and DM'd to them)")
    @app_commands.guild_only()
    @app_commands.default_permissions(kick_members=True)
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.checks.bot_has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: Reason = NO_REASON) -> None:
        if error := hierarchy_error(interaction.user, member):
            return await interaction.response.send_message(error, ephemeral=True)

        await interaction.response.defer()
        await try_dm(member, f"You were kicked from **{interaction.guild.name}**.\nReason: {reason}")
        await member.kick(reason=audit_reason(interaction, reason))

        await interaction.followup.send(f"👢 Kicked **{member}**. Reason: {reason}")
        await self.bot.send_modlog(
            interaction.guild, action_embed("Member kicked", member, interaction.user, reason, discord.Colour.orange())
        )

    # ------------------------------------------------------------------- ban

    @app_commands.command(name="ban", description="Ban a user (works even if they've left the server).")
    @app_commands.describe(
        user="Who to ban — pick a member or paste a user ID",
        delete_days="Delete their messages from the last N days (0-7)",
        reason="Why (shown in the audit log and DM'd to them)",
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def ban(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        delete_days: app_commands.Range[int, 0, 7] = 0,
        reason: Reason = NO_REASON,
    ) -> None:
        member = interaction.guild.get_member(user.id)
        if member is not None:
            if error := hierarchy_error(interaction.user, member):
                return await interaction.response.send_message(error, ephemeral=True)

        await interaction.response.defer()
        if member is not None:
            await try_dm(member, f"You were banned from **{interaction.guild.name}**.\nReason: {reason}")
        await interaction.guild.ban(
            user, reason=audit_reason(interaction, reason), delete_message_seconds=delete_days * 86400
        )

        await interaction.followup.send(f"🔨 Banned **{user}**. Reason: {reason}")
        await self.bot.send_modlog(
            interaction.guild, action_embed("User banned", user, interaction.user, reason, discord.Colour.red())
        )

    @app_commands.command(name="unban", description="Unban a user by their ID.")
    @app_commands.describe(user_id="The banned user's ID", reason="Why")
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: Reason = NO_REASON) -> None:
        if not user_id.strip().isdigit():
            return await interaction.response.send_message("That isn't a valid user ID.", ephemeral=True)

        try:
            ban_entry = await interaction.guild.fetch_ban(discord.Object(id=int(user_id)))
        except discord.NotFound:
            return await interaction.response.send_message("That user isn't banned.", ephemeral=True)

        await interaction.guild.unban(ban_entry.user, reason=audit_reason(interaction, reason))
        await interaction.response.send_message(f"✅ Unbanned **{ban_entry.user}**.")
        await self.bot.send_modlog(
            interaction.guild,
            action_embed("User unbanned", ban_entry.user, interaction.user, reason, discord.Colour.green()),
        )

    # --------------------------------------------------------------- timeout

    @app_commands.command(name="timeout", description="Time out a member so they can't chat or join voice.")
    @app_commands.describe(
        member="Who to time out",
        duration="How long, e.g. 10m, 2h, 1d12h (max 28d)",
        reason="Why",
    )
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.checks.bot_has_permissions(moderate_members=True)
    async def timeout(
        self, interaction: discord.Interaction, member: discord.Member, duration: str, reason: Reason = NO_REASON
    ) -> None:
        delta = parse_duration(duration)
        if delta is None:
            return await interaction.response.send_message(
                "Couldn't read that duration. Try something like `10m`, `2h` or `1d12h`.", ephemeral=True
            )
        if delta > MAX_TIMEOUT:
            return await interaction.response.send_message("Timeouts can be at most 28 days.", ephemeral=True)
        if member.guild_permissions.administrator:
            return await interaction.response.send_message("Administrators can't be timed out.", ephemeral=True)
        if error := hierarchy_error(interaction.user, member):
            return await interaction.response.send_message(error, ephemeral=True)

        await member.timeout(delta, reason=audit_reason(interaction, reason))
        pretty = format_duration(delta)
        await interaction.response.send_message(f"🔇 Timed out {member.mention} for **{pretty}**. Reason: {reason}")
        await try_dm(member, f"You were timed out in **{interaction.guild.name}** for {pretty}.\nReason: {reason}")

        embed = action_embed("Member timed out", member, interaction.user, reason, discord.Colour.dark_orange())
        embed.add_field(name="Duration", value=pretty)
        await self.bot.send_modlog(interaction.guild, embed)

    @app_commands.command(name="untimeout", description="Remove a member's timeout.")
    @app_commands.describe(member="Who to un-timeout", reason="Why")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.checks.bot_has_permissions(moderate_members=True)
    async def untimeout(self, interaction: discord.Interaction, member: discord.Member, reason: Reason = NO_REASON) -> None:
        if not member.is_timed_out():
            return await interaction.response.send_message(f"{member.mention} isn't timed out.", ephemeral=True)

        await member.timeout(None, reason=audit_reason(interaction, reason))
        await interaction.response.send_message(f"🔊 Removed the timeout for {member.mention}.")
        await self.bot.send_modlog(
            interaction.guild, action_embed("Timeout removed", member, interaction.user, reason, discord.Colour.green())
        )

    # -------------------------------------------------------------- warnings

    @app_commands.command(name="warn", description="Give a member a formal warning (saved to their record).")
    @app_commands.describe(member="Who to warn", reason="What they did")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: Reason) -> None:
        if member.bot:
            return await interaction.response.send_message("You can't warn a bot.", ephemeral=True)
        if error := hierarchy_error(interaction.user, member):
            return await interaction.response.send_message(error, ephemeral=True)

        warning_id = await self.bot.db.add_warning(interaction.guild.id, member.id, interaction.user.id, reason)
        total = await self.bot.db.count_warnings(interaction.guild.id, member.id)

        await interaction.response.send_message(
            f"⚠️ Warned {member.mention} (warning #{warning_id}, {total} total). Reason: {reason}"
        )
        await try_dm(member, f"You received a warning in **{interaction.guild.name}**.\nReason: {reason}")

        embed = action_embed("Member warned", member, interaction.user, reason, discord.Colour.gold())
        embed.add_field(name="Total warnings", value=str(total))
        embed.set_footer(text=f"Warning ID {warning_id}")
        await self.bot.send_modlog(interaction.guild, embed)

    @app_commands.command(name="warnings", description="Show a member's warnings.")
    @app_commands.describe(member="Whose record to view")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        rows = await self.bot.db.get_warnings(interaction.guild.id, member.id)
        if not rows:
            return await interaction.response.send_message(f"{member.mention} has no warnings. 🎉", ephemeral=True)

        embed = discord.Embed(title=f"Warnings for {member}", colour=discord.Colour.gold())
        embed.set_thumbnail(url=member.display_avatar.url)
        # Embeds hold max 25 fields; show the most recent 25.
        for row in rows[-25:]:
            when = discord.utils.format_dt(discord.utils.parse_time(row["created_at"]), "R")
            embed.add_field(
                name=f"#{row['id']} · {when}",
                value=f"{truncate(row['reason'], 900)}\n— <@{row['moderator_id']}>",
                inline=False,
            )
        embed.set_footer(text=f"{len(rows)} warning(s) total")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="delwarn", description="Delete a single warning by its ID.")
    @app_commands.describe(warning_id="The warning number shown in /warnings")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def delwarn(self, interaction: discord.Interaction, warning_id: int) -> None:
        if await self.bot.db.delete_warning(interaction.guild.id, warning_id):
            await interaction.response.send_message(f"🗑️ Deleted warning #{warning_id}.", ephemeral=True)
        else:
            await interaction.response.send_message(f"No warning #{warning_id} in this server.", ephemeral=True)

    @app_commands.command(name="clearwarnings", description="Delete all of a member's warnings.")
    @app_commands.describe(member="Whose record to wipe")
    @app_commands.guild_only()
    @app_commands.default_permissions(administrator=True)
    @app_commands.checks.has_permissions(administrator=True)
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        removed = await self.bot.db.clear_warnings(interaction.guild.id, member.id)
        await interaction.response.send_message(f"🧽 Cleared {removed} warning(s) for {member.mention}.", ephemeral=True)
        if removed:
            embed = action_embed("Warnings cleared", member, interaction.user, None, discord.Colour.blurple())
            embed.add_field(name="Removed", value=str(removed))
            await self.bot.send_modlog(interaction.guild, embed)

    # ----------------------------------------------------------------- purge

    @app_commands.command(name="purge", description="Bulk-delete recent messages in this channel.")
    @app_commands.describe(amount="How many messages to delete (1-100)", user="Only delete messages from this user")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.checks.bot_has_permissions(manage_messages=True, read_message_history=True)
    async def purge(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 100],
        user: Optional[discord.User] = None,
    ) -> None:
        channel = interaction.channel
        if not hasattr(channel, "purge"):
            return await interaction.response.send_message("I can't purge this kind of channel.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        remaining = amount

        def should_delete(message: discord.Message) -> bool:
            nonlocal remaining
            if remaining <= 0 or (user is not None and message.author.id != user.id):
                return False
            remaining -= 1
            return True

        # When filtering by user, look further back so we can still find `amount` of their messages.
        scan_limit = amount if user is None else 500
        deleted = await channel.purge(limit=scan_limit, check=should_delete, reason=audit_reason(interaction, "purge"))

        who = f" from {user.mention}" if user else ""
        await interaction.followup.send(f"🧹 Deleted {len(deleted)} message(s){who}.", ephemeral=True)

        embed = discord.Embed(title="Messages purged", colour=discord.Colour.dark_grey(), timestamp=discord.utils.utcnow())
        embed.add_field(name="Channel", value=channel.mention)
        embed.add_field(name="Moderator", value=interaction.user.mention)
        embed.add_field(name="Deleted", value=f"{len(deleted)}{who}")
        await self.bot.send_modlog(interaction.guild, embed)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Moderation(bot))