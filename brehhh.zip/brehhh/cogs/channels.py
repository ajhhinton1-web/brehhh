"""Channel controls: lock, unlock, slowmode."""

from datetime import timedelta
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils import format_duration

if TYPE_CHECKING:
    from bot import AdminBot


def resolve_text_channel(interaction: discord.Interaction, channel: Optional[discord.TextChannel]):
    """Use the given channel, or the current one if it's a normal text channel."""
    if channel is not None:
        return channel
    return interaction.channel if isinstance(interaction.channel, discord.TextChannel) else None


class Channels(commands.Cog):
    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    @app_commands.command(name="lock", description="Stop @everyone from sending messages in a channel.")
    @app_commands.describe(channel="Channel to lock (defaults to this one)", reason="Why")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True, manage_roles=True)
    async def lock(
        self,
        interaction: discord.Interaction,
        channel: Optional[discord.TextChannel] = None,
        reason: app_commands.Range[str, 1, 400] = "No reason provided",
    ) -> None:
        target = resolve_text_channel(interaction, channel)
        if target is None:
            return await interaction.response.send_message("Pick a text channel to lock.", ephemeral=True)

        everyone = interaction.guild.default_role
        overwrite = target.overwrites_for(everyone)
        if overwrite.send_messages is False:
            return await interaction.response.send_message(f"{target.mention} is already locked.", ephemeral=True)

        overwrite.send_messages = False
        overwrite.send_messages_in_threads = False
        overwrite.create_public_threads = False
        await target.set_permissions(everyone, overwrite=overwrite, reason=f"{interaction.user}: {reason}")

        await interaction.response.send_message(f"🔒 Locked {target.mention}.")
        if target != interaction.channel:
            try:
                await target.send(f"🔒 This channel has been locked by a moderator. Reason: {reason}")
            except discord.HTTPException:
                pass

        embed = discord.Embed(title="Channel locked", colour=discord.Colour.dark_red(), timestamp=discord.utils.utcnow())
        embed.add_field(name="Channel", value=target.mention)
        embed.add_field(name="Moderator", value=interaction.user.mention)
        embed.add_field(name="Reason", value=reason, inline=False)
        await self.bot.send_modlog(interaction.guild, embed)

    @app_commands.command(name="unlock", description="Let @everyone send messages in a channel again.")
    @app_commands.describe(channel="Channel to unlock (defaults to this one)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True, manage_roles=True)
    async def unlock(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        target = resolve_text_channel(interaction, channel)
        if target is None:
            return await interaction.response.send_message("Pick a text channel to unlock.", ephemeral=True)

        everyone = interaction.guild.default_role
        overwrite = target.overwrites_for(everyone)
        if overwrite.send_messages is not False:
            return await interaction.response.send_message(f"{target.mention} isn't locked.", ephemeral=True)

        # Reset to "inherit" rather than "allow" so category permissions still apply.
        overwrite.send_messages = None
        overwrite.send_messages_in_threads = None
        overwrite.create_public_threads = None
        await target.set_permissions(
            everyone, overwrite=None if overwrite.is_empty() else overwrite, reason=f"Unlocked by {interaction.user}"
        )

        await interaction.response.send_message(f"🔓 Unlocked {target.mention}.")

        embed = discord.Embed(title="Channel unlocked", colour=discord.Colour.green(), timestamp=discord.utils.utcnow())
        embed.add_field(name="Channel", value=target.mention)
        embed.add_field(name="Moderator", value=interaction.user.mention)
        await self.bot.send_modlog(interaction.guild, embed)

    @app_commands.command(name="slowmode", description="Set how often members can send messages in a channel.")
    @app_commands.describe(seconds="Seconds between messages (0 turns it off, max 21600 = 6h)", channel="Defaults to this one")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True)
    async def slowmode(
        self,
        interaction: discord.Interaction,
        seconds: app_commands.Range[int, 0, 21600],
        channel: Optional[discord.TextChannel] = None,
    ) -> None:
        target = resolve_text_channel(interaction, channel)
        if target is None:
            return await interaction.response.send_message("Pick a text channel.", ephemeral=True)

        await target.edit(slowmode_delay=seconds, reason=f"Set by {interaction.user}")
        if seconds == 0:
            await interaction.response.send_message(f"⏱️ Slowmode turned off in {target.mention}.")
        else:
            pretty = format_duration(timedelta(seconds=seconds))
            await interaction.response.send_message(f"⏱️ Slowmode in {target.mention} set to **{pretty}**.")


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Channels(bot))