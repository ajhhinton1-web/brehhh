"""Automatic event logging to the mod-log channel (set with /setlogchannel).

Note: Discord only tells the bot *what* a deleted/edited message said if the
message was sent while the bot was online (it's read from the bot's cache).
Bulk deletes from /purge are summarised by the purge command itself.
"""

from datetime import timedelta
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from utils import truncate

if TYPE_CHECKING:
    from bot import AdminBot

NEW_ACCOUNT_AGE = timedelta(days=7)  # flag accounts younger than this when they join


class Logs(commands.Cog):
    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    async def _skip(self, message: discord.Message) -> bool:
        """Ignore DMs, bots, and the log channel itself."""
        if message.guild is None or message.author.bot:
            return True
        return message.channel.id == await self.bot.db.get_log_channel(message.guild.id)

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message) -> None:
        if await self._skip(message):
            return
        embed = discord.Embed(
            title="Message deleted",
            description=truncate(message.content, 4000) or "*(no text)*",
            colour=discord.Colour.red(),
            timestamp=discord.utils.utcnow(),
        )
        embed.set_author(name=str(message.author), icon_url=message.author.display_avatar.url)
        embed.add_field(name="Channel", value=message.channel.mention)
        embed.add_field(name="Author", value=f"{message.author.mention} (`{message.author.id}`)")
        if message.attachments:
            names = "\n".join(a.filename for a in message.attachments)
            embed.add_field(name="Attachments", value=truncate(names), inline=False)
        await self.bot.send_modlog(message.guild, embed)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        if await self._skip(after) or before.content == after.content:
            return  # also skips link-preview updates, which fire edit events with the same text
        embed = discord.Embed(
            title="Message edited",
            description=f"[Jump to message]({after.jump_url})",
            colour=discord.Colour.blue(),
            timestamp=discord.utils.utcnow(),
        )
        embed.set_author(name=str(after.author), icon_url=after.author.display_avatar.url)
        embed.add_field(name="Before", value=truncate(before.content) or "*(empty)*", inline=False)
        embed.add_field(name="After", value=truncate(after.content) or "*(empty)*", inline=False)
        embed.add_field(name="Channel", value=after.channel.mention)
        await self.bot.send_modlog(after.guild, embed)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        age = discord.utils.utcnow() - member.created_at
        embed = discord.Embed(
            title="Member joined",
            description=f"{member.mention} (`{member.id}`)",
            colour=discord.Colour.green(),
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Account created", value=discord.utils.format_dt(member.created_at, "R"))
        embed.add_field(name="Member count", value=str(member.guild.member_count))
        if age < NEW_ACCOUNT_AGE:
            embed.add_field(name="⚠️ New account", value="Created less than 7 days ago", inline=False)
            embed.colour = discord.Colour.orange()
        await self.bot.send_modlog(member.guild, embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        embed = discord.Embed(
            title="Member left",
            description=f"{member} (`{member.id}`)",
            colour=discord.Colour.light_grey(),
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        if member.joined_at:
            embed.add_field(name="Joined", value=discord.utils.format_dt(member.joined_at, "R"))
        roles = [r.mention for r in member.roles if not r.is_default()]
        if roles:
            embed.add_field(name="Roles", value=truncate(" ".join(roles)), inline=False)
        await self.bot.send_modlog(member.guild, embed)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Logs(bot))