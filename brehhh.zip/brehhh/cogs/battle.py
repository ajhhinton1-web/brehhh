"""Modern-military battle system.

Players earn XP from battles and missions to rank up from Private to General.
Higher ranks unlock better gear in the armory (bought with economy coins).

Commands: /battle, /mission, /profile, /ranks, /topsoldiers, /armory view|buy|equip
"""

import random
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Dict, List, Literal, Optional, Set, Tuple

import discord
from discord import app_commands
from discord.ext import commands

from cogs.economy import COIN, coins, ready_in

if TYPE_CHECKING:
    from bot import AdminBot

# ================================================================ SETTINGS

BASE_HP = 100
HP_PER_RANK = 3              # every rank adds this much max HP
MEDKITS = 1                  # per battle
MEDKIT_HEAL = (25, 35)
CRIT_CHANCE = 0.10
CRIT_MULTIPLIER = 1.5
COVER_REDUCTION = 0.5        # cover halves incoming gunfire (not support strikes)
MAX_TURNS = 40               # after this, whoever has the most HP left (as a %) wins
TURN_TIMEOUT = 60            # seconds before an idle player forfeits
CHALLENGE_TIMEOUT = 60

WIN_XP = 50
WIN_XP_PER_RANK_GAP = 10     # extra XP for beating someone who outranks you, per rank
LOSS_XP = 15
# The coin bonus for winning a battle is set per server with /setup or /config amount.
BATTLE_REWARD_COOLDOWN = 300  # XP/coins from battles at most once per 5 min (stops farming with alts)
PROMOTION_BONUS = 500         # coins × new rank number

MISSION_COOLDOWN = 1800
MISSION_FAIL_XP = 0.3         # fraction of XP you still get when a mission fails


@dataclass(frozen=True)
class Rank:
    name: str
    abbr: str
    xp: int


RANKS = [
    Rank("Private", "PVT", 0),
    Rank("Private First Class", "PFC", 100),
    Rank("Corporal", "CPL", 250),
    Rank("Sergeant", "SGT", 450),
    Rank("Staff Sergeant", "SSG", 700),
    Rank("Sergeant First Class", "SFC", 1000),
    Rank("Master Sergeant", "MSG", 1400),
    Rank("Sergeant Major", "SGM", 1900),
    Rank("Second Lieutenant", "2LT", 2500),
    Rank("First Lieutenant", "1LT", 3200),
    Rank("Captain", "CPT", 4000),
    Rank("Major", "MAJ", 5000),
    Rank("Lieutenant Colonel", "LTC", 6200),
    Rank("Colonel", "COL", 7600),
    Rank("Brigadier General", "BG", 9200),
    Rank("Major General", "MG", 11000),
    Rank("Lieutenant General", "LTG", 13500),
    Rank("General", "GEN", 16500),
]


@dataclass(frozen=True)
class Gear:
    key: str
    slot: str                 # "weapon", "armor" or "support"
    emoji: str
    name: str
    price: int
    rank: int                 # index in RANKS needed to buy it
    tier: int                 # rough power level, used for mission success chance
    damage: Tuple[int, int] = (0, 0)
    accuracy: float = 1.0
    protection: float = 0.0   # armor: fraction of damage blocked


GEAR: Dict[str, Gear] = {g.key: g for g in [
    # weapons: fired every turn
    Gear("pistol", "weapon", "🔫", "Service Pistol", 0, 0, 0, (18, 26), 0.90),
    Gear("smg", "weapon", "🔫", "Submachine Gun", 2_000, 1, 1, (20, 29), 0.88),
    Gear("rifle", "weapon", "🔫", "Assault Rifle", 5_000, 3, 2, (23, 32), 0.85),
    Gear("lmg", "weapon", "🔫", "Light Machine Gun", 9_000, 5, 3, (20, 44), 0.80),
    Gear("sniper", "weapon", "🎯", "Sniper Rifle", 16_000, 8, 4, (34, 52), 0.70),
    Gear("antimateriel", "weapon", "🎯", "Anti-Materiel Rifle", 30_000, 12, 5, (40, 60), 0.68),
    # armor: reduces all damage taken
    Gear("none", "armor", "👕", "No Armor", 0, 0, 0),
    Gear("vest", "armor", "🦺", "Kevlar Vest", 1_500, 0, 1, protection=0.08),
    Gear("plate", "armor", "🦺", "Plate Carrier", 6_000, 4, 2, protection=0.13),
    Gear("heavy", "armor", "🛡️", "Heavy Body Armor", 14_000, 7, 3, protection=0.18),
    Gear("exo", "armor", "🤖", "Combat Exoskeleton", 28_000, 11, 4, protection=0.24),
    # support: one big hit per battle that ignores cover
    Gear("grenade", "support", "💣", "Frag Grenade", 0, 0, 0, (28, 38)),
    Gear("mortar", "support", "💥", "Mortar Strike", 4_000, 2, 1, (32, 44)),
    Gear("drone", "support", "🛸", "Drone Strike", 10_000, 6, 2, (38, 50)),
    Gear("artillery", "support", "💥", "Artillery Barrage", 18_000, 9, 3, (44, 58)),
    Gear("airstrike", "support", "✈️", "Airstrike", 35_000, 13, 4, (50, 66)),
]}
STARTER_GEAR = {"weapon": "pistol", "armor": "none", "support": "grenade"}


@dataclass(frozen=True)
class MissionTier:
    label: str
    success: float
    coins: Tuple[int, int]
    xp: Tuple[int, int]
    names: Tuple[str, ...]


MISSIONS = {
    "easy": MissionTier("🟢 Easy", 0.80, (80, 150), (15, 25), (
        "Recon patrol along the border",
        "Escort a supply convoy",
        "Secure a forward checkpoint",
        "Sweep an abandoned village",
    )),
    "medium": MissionTier("🟡 Medium", 0.60, (160, 300), (30, 45), (
        "Clear an enemy outpost",
        "Rescue a downed pilot",
        "Defend the airfield until reinforcements arrive",
        "Capture a radio relay station",
    )),
    "hard": MissionTier("🔴 Hard", 0.40, (320, 600), (55, 80), (
        "Night raid on an enemy command post",
        "Hold the bridge against an armoured assault",
        "Extract an intel asset from behind enemy lines",
        "Sabotage an enemy supply depot",
    )),
}

# ================================================================= helpers


def rank_index(xp: int) -> int:
    index = 0
    for i, rank in enumerate(RANKS):
        if xp >= rank.xp:
            index = i
    return index


def insignia(index: int) -> str:
    if index <= 1:
        return "🪖"
    if index <= 7:
        return "🎗️"
    if index <= 13:
        return "🎖️"
    return "⭐" * (index - 13)  # generals get 1-4 stars


def rank_label(index: int) -> str:
    return f"{insignia(index)} {RANKS[index].name}"


def max_hp(rank: int) -> int:
    return BASE_HP + HP_PER_RANK * rank


def bar(fraction: float, length: int = 10) -> str:
    filled = max(0, min(length, round(fraction * length)))
    colour = "🟩" if fraction > 0.6 else "🟨" if fraction > 0.3 else "🟥"
    return colour * filled + "⬛" * (length - filled)


def gear_stats(g: Gear) -> str:
    if g.slot == "weapon":
        return f"{g.damage[0]}-{g.damage[1]} dmg · {round(g.accuracy * 100)}% accuracy"
    if g.slot == "armor":
        return f"blocks {round(g.protection * 100)}% damage"
    return f"{g.damage[0]}-{g.damage[1]} dmg, once per battle"


def equipped(key: str, slot: str) -> Gear:
    """Look up equipped gear, falling back to the starter item if something's wrong."""
    gear = GEAR.get(key)
    return gear if gear is not None and gear.slot == slot else GEAR[STARTER_GEAR[slot]]


# ============================================================ battle engine


@dataclass
class Fighter:
    user: discord.abc.User
    rank: int
    weapon: Gear
    armor: Gear
    support: Gear
    max_hp: int
    hp: int
    medkits: int = MEDKITS
    special_ready: bool = True
    in_cover: bool = False
    last_action: str = ""

    @property
    def name(self) -> str:
        return self.user.display_name


def make_fighter(user: discord.abc.User, soldier) -> Fighter:
    rank = rank_index(soldier.xp)
    hp = max_hp(rank)
    return Fighter(
        user=user,
        rank=rank,
        weapon=equipped(soldier.weapon, "weapon"),
        armor=equipped(soldier.armor, "armor"),
        support=equipped(soldier.support, "support"),
        max_hp=hp,
        hp=hp,
    )


class Battle:
    """Pure game logic, no Discord calls, so it's easy to test and tweak."""

    def __init__(self, a: Fighter, b: Fighter, rng: random.Random = random) -> None:
        self.fighters = [a, b]
        self.rng = rng
        self.turn = rng.randrange(2)
        self.turns_taken = 0
        self.log: List[str] = []
        self.over = False
        self.winner: Optional[Fighter] = None
        self.reason = ""

    @property
    def current(self) -> Fighter:
        return self.fighters[self.turn]

    @property
    def opponent(self) -> Fighter:
        return self.fighters[1 - self.turn]

    @property
    def loser(self) -> Optional[Fighter]:
        if self.winner is None:
            return None
        return self.fighters[1] if self.winner is self.fighters[0] else self.fighters[0]

    def problem_with(self, action: str) -> Optional[str]:
        """Why the current player can't do `action` right now, or None if they can."""
        me = self.current
        if action == "special" and not me.special_ready:
            return f"You've already used your {me.support.name} this battle."
        if action == "medkit":
            if me.medkits <= 0:
                return "You're out of medkits."
            if me.hp >= me.max_hp:
                return "You're already at full health."
        if action == "cover" and me.last_action == "cover":
            return "You can't take cover twice in a row. Make a move!"
        return None

    def _mitigate(self, target: Fighter, damage: int, gunfire: bool) -> int:
        damage *= 1 - target.armor.protection
        if gunfire and target.in_cover:
            damage *= COVER_REDUCTION
        return max(1, round(damage))

    def act(self, action: str) -> None:
        me, foe = self.current, self.opponent
        me.in_cover = False  # cover only lasts until your next turn

        if action == "surrender":
            self.log.append(f"🏳️ **{me.name}** surrendered.")
            self.finish(foe, f"{me.name} surrendered")
            return

        if action == "fire":
            if self.rng.random() > me.weapon.accuracy:
                self.log.append(f"{me.weapon.emoji} **{me.name}** fires their {me.weapon.name}... and misses!")
            else:
                damage = self.rng.randint(*me.weapon.damage)
                crit = self.rng.random() < CRIT_CHANCE
                if crit:
                    damage = int(damage * CRIT_MULTIPLIER)
                covered = foe.in_cover
                damage = self._mitigate(foe, damage, gunfire=True)
                foe.hp = max(0, foe.hp - damage)
                extra = " 💥 **CRITICAL HIT!**" if crit else ""
                extra += " *(target in cover)*" if covered else ""
                self.log.append(f"{me.weapon.emoji} **{me.name}** fires their {me.weapon.name}: **{damage}** damage.{extra}")

        elif action == "special":
            me.special_ready = False
            damage = self._mitigate(foe, self.rng.randint(*me.support.damage), gunfire=False)
            foe.hp = max(0, foe.hp - damage)
            self.log.append(f"{me.support.emoji} **{me.name}** uses **{me.support.name}**: **{damage}** damage!")

        elif action == "cover":
            me.in_cover = True
            self.log.append(f"🛡️ **{me.name}** takes cover.")

        elif action == "medkit":
            me.medkits -= 1
            healed = min(self.rng.randint(*MEDKIT_HEAL), me.max_hp - me.hp)
            me.hp += healed
            self.log.append(f"💉 **{me.name}** patches up: +**{healed}** HP.")

        else:
            raise ValueError(f"Unknown action {action!r}")

        me.last_action = action
        if foe.hp <= 0:
            self.finish(me, f"{foe.name} is down")
            return

        self.turns_taken += 1
        if self.turns_taken >= MAX_TURNS:
            a, b = self.fighters
            ratio_a, ratio_b = a.hp / a.max_hp, b.hp / b.max_hp
            if ratio_a == ratio_b:
                self.finish(None, "time ran out with both sides even")
            else:
                self.finish(a if ratio_a > ratio_b else b, "time ran out; most health left wins")
            return
        self.turn = 1 - self.turn

    def finish(self, winner: Optional[Fighter], reason: str) -> None:
        self.over = True
        self.winner = winner
        self.reason = reason


# ================================================================== views


class BattleView(discord.ui.View):
    def __init__(self, cog: "Battles", battle: Battle, guild_id: int, wager: int) -> None:
        super().__init__(timeout=TURN_TIMEOUT)
        self.cog = cog
        self.battle = battle
        self.guild_id = guild_id
        self.wager = wager
        self.message: Optional[discord.Message] = None
        self.sync_buttons()

    # ---- display

    def render(self) -> discord.Embed:
        b = self.battle
        a, c = b.fighters
        embed = discord.Embed(title=f"⚔️ {a.name} vs {c.name}", colour=discord.Colour.gold() if b.over else discord.Colour.dark_red())
        if b.over:
            embed.description = f"🏆 **{b.winner.name} wins!** ({b.reason})" if b.winner else f"🤝 **Draw!** ({b.reason})"
        else:
            embed.description = f"➡️ **{b.current.name}**, it's your turn! ({TURN_TIMEOUT}s)"

        for f in b.fighters:
            lines = [
                f"{bar(f.hp / f.max_hp)} **{f.hp}/{f.max_hp}** HP",
                f"{f.weapon.emoji} {f.weapon.name}",
                f"{f.armor.emoji} {f.armor.name}",
                f"{f.support.emoji} {f.support.name} {'✅' if f.special_ready else '❌'}",
                f"💉 {f.medkits} medkit(s)",
            ]
            if f.in_cover:
                lines.append("🛡️ **In cover**")
            turn_marker = " ⬅️" if (not b.over and f is b.current) else ""
            embed.add_field(name=f"{insignia(f.rank)} {RANKS[f.rank].abbr} {f.name}{turn_marker}", value="\n".join(lines))

        embed.add_field(name="📜 Combat log", value="\n".join(b.log[-5:]) or "Weapons ready. Fight!", inline=False)
        footer = f"Turn {b.turns_taken + 1}/{MAX_TURNS}"
        if self.wager:
            footer += f" · Pot: {self.wager * 2:,} coins"
        embed.set_footer(text=footer)
        return embed

    def sync_buttons(self) -> None:
        """Buttons are shared, so update them for whoever's turn it is."""
        me = self.battle.current
        self.special_button.label = me.support.name
        self.special_button.emoji = me.support.emoji
        self.special_button.disabled = not me.special_ready
        self.medkit_button.label = f"Medkit ({me.medkits})"
        self.medkit_button.disabled = me.medkits <= 0
        self.cover_button.disabled = me.last_action == "cover"
        if self.battle.over:
            for child in self.children:
                child.disabled = True

    # ---- input

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        b = self.battle
        if interaction.user.id not in (f.user.id for f in b.fighters):
            await interaction.response.send_message("You're not in this battle. Start your own with `/battle`!", ephemeral=True)
            return False
        if b.over:
            await interaction.response.send_message("This battle is over.", ephemeral=True)
            return False
        if interaction.user.id != b.current.user.id:
            await interaction.response.send_message("Hold your fire, it's not your turn!", ephemeral=True)
            return False
        return True

    async def take_turn(self, interaction: discord.Interaction, action: str) -> None:
        problem = self.battle.problem_with(action)
        if problem:
            return await interaction.response.send_message(problem, ephemeral=True)

        self.battle.act(action)
        self.sync_buttons()
        if self.battle.over:
            self.stop()
        await interaction.response.edit_message(content=None, embed=self.render(), view=self)
        if self.battle.over:
            summary = await self.cog.finish_battle(self)
            await interaction.followup.send(summary)

    @discord.ui.button(label="Fire", emoji="🔫", style=discord.ButtonStyle.danger, row=0)
    async def fire_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.take_turn(interaction, "fire")

    @discord.ui.button(label="Support", emoji="💣", style=discord.ButtonStyle.primary, row=0)
    async def special_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.take_turn(interaction, "special")

    @discord.ui.button(label="Take Cover", emoji="🛡️", style=discord.ButtonStyle.secondary, row=0)
    async def cover_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.take_turn(interaction, "cover")

    @discord.ui.button(label="Medkit", emoji="💉", style=discord.ButtonStyle.success, row=0)
    async def medkit_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.take_turn(interaction, "medkit")

    @discord.ui.button(label="Surrender", emoji="🏳️", style=discord.ButtonStyle.secondary, row=1)
    async def surrender_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.take_turn(interaction, "surrender")

    async def on_timeout(self) -> None:
        if self.battle.over:
            return
        idle = self.battle.current
        self.battle.log.append(f"💤 **{idle.name}** went AFK and forfeits.")
        self.battle.finish(self.battle.opponent, f"{idle.name} didn't move in time")
        self.sync_buttons()
        summary = await self.cog.finish_battle(self)
        if self.message is not None:
            try:
                await self.message.edit(content=None, embed=self.render(), view=self)
                await self.message.reply(summary)
            except discord.HTTPException:
                pass


class ChallengeView(discord.ui.View):
    def __init__(self, cog: "Battles", challenger: discord.Member, opponent: discord.Member, wager: int) -> None:
        super().__init__(timeout=CHALLENGE_TIMEOUT)
        self.cog = cog
        self.challenger = challenger
        self.opponent = opponent
        self.wager = wager
        self.answered = False
        self.message: Optional[discord.InteractionMessage] = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id not in (self.challenger.id, self.opponent.id):
            await interaction.response.send_message("This challenge isn't for you.", ephemeral=True)
            return False
        if self.answered:
            await interaction.response.send_message("This challenge has already been answered.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Accept", emoji="⚔️", style=discord.ButtonStyle.success)
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        if interaction.user.id != self.opponent.id:
            return await interaction.response.send_message(f"Only {self.opponent.display_name} can accept.", ephemeral=True)
        self.answered = True
        self.stop()
        await self.cog.start_battle(interaction, self)

    @discord.ui.button(label="Decline", emoji="✖️", style=discord.ButtonStyle.danger)
    async def decline(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.answered = True
        self.stop()
        self.cog.release(interaction.guild_id, self.challenger.id, self.opponent.id)
        verb = "cancelled" if interaction.user.id == self.challenger.id else "declined"
        embed = discord.Embed(description=f"✖️ {interaction.user.mention} {verb} the battle.", colour=discord.Colour.greyple())
        await interaction.response.edit_message(content=None, embed=embed, view=None)

    async def on_timeout(self) -> None:
        if self.answered:
            return
        self.cog.release(self.challenger.guild.id, self.challenger.id, self.opponent.id)
        if self.message is not None:
            try:
                embed = discord.Embed(description=f"⌛ {self.opponent.mention} didn't answer. Challenge expired.", colour=discord.Colour.greyple())
                await self.message.edit(content=None, embed=embed, view=None)
            except discord.HTTPException:
                pass


# ==================================================================== cog


class Battles(commands.Cog):
    MODULE = "battles"  # can be switched off per server with /config module

    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot
        self.busy: Set[Tuple[int, int]] = set()  # (guild_id, user_id) of people in a battle/challenge

    @property
    def db(self):
        return self.bot.db

    def release(self, guild_id: int, *user_ids: int) -> None:
        for uid in user_ids:
            self.busy.discard((guild_id, uid))

    async def promotion_message(self, guild_id: int, user: discord.abc.User, old_xp: int, new_xp: int) -> Optional[str]:
        old_rank, new_rank = rank_index(old_xp), rank_index(new_xp)
        if new_rank <= old_rank:
            return None
        bonus = PROMOTION_BONUS * new_rank
        await self.db.add_wallet(guild_id, user.id, bonus)
        text = f"🎉 **PROMOTION!** {user.mention} is now **{rank_label(new_rank)}**! Bonus: {coins(bonus)}"
        unlocked = [g for g in GEAR.values() if old_rank < g.rank <= new_rank]
        if unlocked:
            text += "\n🔓 New gear unlocked in `/armory`: " + ", ".join(f"{g.emoji} {g.name}" for g in unlocked)
        return text

    # ============================================================== battle

    @app_commands.command(name="battle", description="Challenge another member to a battle.")
    @app_commands.describe(opponent="Who to fight", wager="Coins each side puts in. Winner takes the lot (optional)")
    @app_commands.guild_only()
    async def battle(self, interaction: discord.Interaction, opponent: discord.Member, wager: app_commands.Range[int, 0, 1_000_000] = 0) -> None:
        gid, challenger = interaction.guild_id, interaction.user
        if opponent.id == challenger.id or opponent.bot:
            return await interaction.response.send_message("Pick a real opponent. You can't fight yourself or a bot.", ephemeral=True)
        if (gid, challenger.id) in self.busy:
            return await interaction.response.send_message("You're already in a battle or have a challenge pending.", ephemeral=True)
        if (gid, opponent.id) in self.busy:
            return await interaction.response.send_message(f"{opponent.display_name} is already in a battle.", ephemeral=True)
        if wager:
            for person in (challenger, opponent):
                wallet = (await self.db.get_account(gid, person.id)).wallet
                if wallet < wager:
                    who = "You don't" if person is challenger else f"{person.display_name} doesn't"
                    return await interaction.response.send_message(f"{who} have {coins(wager)} in their wallet.", ephemeral=True)

        self.busy.update({(gid, challenger.id), (gid, opponent.id)})
        try:
            c_rank = rank_index((await self.db.get_soldier(gid, challenger.id)).xp)
            o_rank = rank_index((await self.db.get_soldier(gid, opponent.id)).xp)
            embed = discord.Embed(
                title="⚔️ Battle challenge!",
                description=(
                    f"{rank_label(c_rank)} {challenger.mention} challenges {rank_label(o_rank)} {opponent.mention}!"
                    + (f"\n💰 Wager: {coins(wager)} each, winner takes {coins(wager * 2)}" if wager else "")
                ),
                colour=discord.Colour.dark_red(),
            )
            embed.set_footer(text=f"{opponent.display_name} has {CHALLENGE_TIMEOUT} seconds to respond")
            view = ChallengeView(self, challenger, opponent, wager)
            await interaction.response.send_message(content=opponent.mention, embed=embed, view=view)
            view.message = await interaction.original_response()
        except Exception:
            self.release(gid, challenger.id, opponent.id)
            raise

    async def start_battle(self, interaction: discord.Interaction, challenge: ChallengeView) -> None:
        gid = interaction.guild_id
        a, b, wager = challenge.challenger, challenge.opponent, challenge.wager

        if wager:
            if not await self.db.spend_wallet(gid, a.id, wager):
                self.release(gid, a.id, b.id)
                return await interaction.response.edit_message(content=f"✖️ {a.mention} can no longer afford the wager.", embed=None, view=None)
            if not await self.db.spend_wallet(gid, b.id, wager):
                await self.db.add_wallet(gid, a.id, wager)  # refund
                self.release(gid, a.id, b.id)
                return await interaction.response.edit_message(content=f"✖️ {b.mention} can't afford the wager.", embed=None, view=None)

        battle = Battle(
            make_fighter(a, await self.db.get_soldier(gid, a.id)),
            make_fighter(b, await self.db.get_soldier(gid, b.id)),
        )
        view = BattleView(self, battle, gid, wager)
        view.message = interaction.message
        await interaction.response.edit_message(
            content=f"{battle.current.user.mention}, you're up first!", embed=view.render(), view=view
        )

    async def finish_battle(self, view: BattleView) -> str:
        battle, gid, wager = view.battle, view.guild_id, view.wager
        a, b = battle.fighters
        self.release(gid, a.user.id, b.user.id)

        if battle.winner is None:
            if wager:
                await self.db.add_wallet(gid, a.user.id, wager)
                await self.db.add_wallet(gid, b.user.id, wager)
            return "🤝 The battle ended in a draw." + (" Wagers refunded." if wager else "")

        winner, loser = battle.winner, battle.loser
        lines = [f"🏆 **{winner.user.mention} wins the battle!**"]
        if wager:
            await self.db.add_wallet(gid, winner.user.id, wager * 2)
            lines.append(f"💰 Takes the pot of {coins(wager * 2)}")

        now = time.time()
        win_coins = (await self.db.get_settings(gid)).battle_win_coins
        for fighter, other, won in ((winner, loser, True), (loser, winner, False)):
            uid = fighter.user.id
            on_cooldown = await self.db.claim_cooldown(gid, uid, "battle_reward", now, BATTLE_REWARD_COOLDOWN)
            if on_cooldown is not None:
                await self.db.add_xp(gid, uid, 0, won)  # still count the win/loss
                lines.append(f"⏳ {fighter.user.mention}: no XP this time (battle rewards ready {ready_in(on_cooldown)})")
                continue

            xp = WIN_XP + WIN_XP_PER_RANK_GAP * max(0, other.rank - fighter.rank) if won else LOSS_XP
            new_xp = await self.db.add_xp(gid, uid, xp, won)
            if won:
                await self.db.add_wallet(gid, uid, win_coins)
                lines.append(f"⭐ {fighter.user.mention}: +{xp} XP" + (f", +{coins(win_coins)}" if win_coins else ""))
            else:
                lines.append(f"🎖️ {fighter.user.mention}: +{xp} XP for showing up")
            promo = await self.promotion_message(gid, fighter.user, new_xp - xp, new_xp)
            if promo:
                lines.append(promo)
        return "\n".join(lines)

    # ============================================================= mission

    @app_commands.command(name="mission", description="Go on a solo mission for XP and coins (every 30 min).")
    @app_commands.describe(difficulty="Harder missions pay more but fail more often")
    @app_commands.guild_only()
    async def mission(self, interaction: discord.Interaction, difficulty: Literal["easy", "medium", "hard"]) -> None:
        gid, user = interaction.guild_id, interaction.user
        ready = await self.db.claim_cooldown(gid, user.id, "mission", time.time(), MISSION_COOLDOWN)
        if ready is not None:
            return await interaction.response.send_message(f"⏳ Your unit is resting. Next mission {ready_in(ready)}.", ephemeral=True)

        tier = MISSIONS[difficulty]
        soldier = await self.db.get_soldier(gid, user.id)
        rank = rank_index(soldier.xp)
        gear_power = sum(equipped(key, slot).tier for key, slot in (
            (soldier.weapon, "weapon"), (soldier.armor, "armor"), (soldier.support, "support")))
        chance = min(0.95, tier.success + 0.02 * gear_power + 0.005 * rank)
        name = random.choice(tier.names)

        xp = random.randint(*tier.xp)
        if random.random() < chance:
            reward = random.randint(*tier.coins)
            await self.db.add_wallet(gid, user.id, reward)
            outcome = f"✅ **Mission accomplished!**\nYou earned {coins(reward)} and **{xp} XP**."
            colour = discord.Colour.green()
        else:
            xp = max(1, int(xp * MISSION_FAIL_XP))
            outcome = f"❌ **Mission failed.** Your squad had to fall back.\nYou still learned something: **{xp} XP**."
            colour = discord.Colour.red()

        new_xp = await self.db.add_xp(gid, user.id, xp)
        embed = discord.Embed(title=f"{tier.label} mission: {name}", description=outcome, colour=colour)
        embed.set_footer(text=f"Success chance was {round(chance * 100)}% · Better gear and rank raise it")
        promo = await self.promotion_message(gid, user, new_xp - xp, new_xp)
        await interaction.response.send_message(content=promo, embed=embed)

    # ============================================================= profile

    @app_commands.command(name="profile", description="View a soldier's service record.")
    @app_commands.describe(member="Whose record to view (defaults to you)")
    @app_commands.guild_only()
    async def profile(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        member = member or interaction.user
        s = await self.db.get_soldier(interaction.guild_id, member.id)
        rank = rank_index(s.xp)

        embed = discord.Embed(title=f"📋 Service record: {member.display_name}", colour=discord.Colour.dark_green())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Rank", value=f"{rank_label(rank)} ({RANKS[rank].abbr})")
        if rank + 1 < len(RANKS):
            current, nxt = RANKS[rank], RANKS[rank + 1]
            progress = (s.xp - current.xp) / (nxt.xp - current.xp)
            embed.add_field(name="Next promotion", value=f"{bar(progress)}\n{s.xp:,}/{nxt.xp:,} XP → {nxt.name}")
        else:
            embed.add_field(name="Next promotion", value=f"🏅 Highest rank reached! ({s.xp:,} XP)")

        battles = s.wins + s.losses
        win_rate = f"{round(100 * s.wins / battles)}%" if battles else "N/A"
        embed.add_field(name="Battle record", value=f"{s.wins}W / {s.losses}L · win rate {win_rate}")

        loadout = [equipped(s.weapon, "weapon"), equipped(s.armor, "armor"), equipped(s.support, "support")]
        embed.add_field(
            name=f"Loadout · {max_hp(rank)} max HP",
            value="\n".join(f"{g.emoji} {g.name} · *{gear_stats(g)}*" for g in loadout),
            inline=False,
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ranks", description="See every rank and how much XP it takes.")
    @app_commands.guild_only()
    async def ranks(self, interaction: discord.Interaction) -> None:
        mine = rank_index((await self.db.get_soldier(interaction.guild_id, interaction.user.id)).xp)
        lines = []
        for i, r in enumerate(RANKS):
            you = "  ⬅️ **you**" if i == mine else ""
            lines.append(f"{insignia(i)} `{r.abbr:>3}` {r.name} · {r.xp:,} XP{you}")
        embed = discord.Embed(title="🎖️ Ranks", description="\n".join(lines), colour=discord.Colour.dark_green())
        embed.set_footer(text="Earn XP from /battle and /mission. Each promotion pays a coin bonus and unlocks gear.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="topsoldiers", description="The highest-ranked soldiers in this server.")
    @app_commands.guild_only()
    async def topsoldiers(self, interaction: discord.Interaction) -> None:
        rows = await self.db.military_leaderboard(interaction.guild_id, 10)
        if not rows:
            return await interaction.response.send_message("No soldiers yet. Try `/mission` or `/battle`!")
        medals = ["🥇", "🥈", "🥉"]
        lines = []
        for i, row in enumerate(rows):
            r = rank_index(row["xp"])
            place = medals[i] if i < 3 else f"`#{i + 1}`"
            lines.append(f"{place} {insignia(r)} **{RANKS[r].abbr}** <@{row['user_id']}> · {row['xp']:,} XP · {row['wins']}W/{row['losses']}L")
        embed = discord.Embed(title=f"🎖️ Top soldiers in {interaction.guild.name}", description="\n".join(lines), colour=discord.Colour.dark_green())
        await interaction.response.send_message(embed=embed)

    # ============================================================== armory

    armory = app_commands.Group(name="armory", description="Military gear: view, buy and equip.", guild_only=True)

    @armory.command(name="view", description="See all gear, prices and which rank unlocks it.")
    async def armory_view(self, interaction: discord.Interaction) -> None:
        gid, uid = interaction.guild_id, interaction.user.id
        s = await self.db.get_soldier(gid, uid)
        rank = rank_index(s.xp)
        owned = await self.db.owned_gear(gid, uid)
        current = {"weapon": s.weapon, "armor": s.armor, "support": s.support}

        embed = discord.Embed(title="🏭 Armory", colour=discord.Colour.dark_green())
        embed.description = f"Your rank: {rank_label(rank)} · Buy with `/armory buy`, switch with `/armory equip`"
        for slot, title in (("weapon", "🔫 Weapons"), ("armor", "🦺 Armor"), ("support", "💣 Support (one use per battle)")):
            lines = []
            for g in (g for g in GEAR.values() if g.slot == slot):
                if current[slot] == g.key:
                    status = "✅ **Equipped**"
                elif g.price == 0 or g.key in owned:
                    status = "Owned"
                elif rank < g.rank:
                    status = f"🔒 {RANKS[g.rank].name}"
                else:
                    status = f"{g.price:,} {COIN}"
                lines.append(f"{g.emoji} **{g.name}** · {gear_stats(g)} · {status}")
            embed.add_field(name=title, value="\n".join(lines), inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @armory.command(name="buy", description="Buy a piece of gear (it's equipped automatically).")
    @app_commands.describe(gear="What to buy")
    @app_commands.choices(gear=[
        app_commands.Choice(name=f"{g.name} ({g.price:,} coins, {RANKS[g.rank].abbr}+)", value=g.key)
        for g in GEAR.values() if g.price > 0
    ])
    async def armory_buy(self, interaction: discord.Interaction, gear: str) -> None:
        gid, uid = interaction.guild_id, interaction.user.id
        g = GEAR[gear]
        rank = rank_index((await self.db.get_soldier(gid, uid)).xp)
        if rank < g.rank:
            return await interaction.response.send_message(
                f"🔒 You need to be a **{RANKS[g.rank].name}** to requisition the {g.name}. You're a {RANKS[rank].name}.", ephemeral=True
            )
        if g.key in await self.db.owned_gear(gid, uid):
            return await interaction.response.send_message(f"You already own the {g.name}. Use `/armory equip`.", ephemeral=True)
        if not await self.db.buy_gear(gid, uid, g.key, g.slot, g.price):
            return await interaction.response.send_message(f"The {g.name} costs {coins(g.price)}. You don't have enough in your wallet.", ephemeral=True)
        await interaction.response.send_message(f"✅ Requisitioned and equipped {g.emoji} **{g.name}** for {coins(g.price)}. *({gear_stats(g)})*")

    @armory.command(name="equip", description="Switch to gear you already own.")
    @app_commands.describe(gear="What to equip")
    @app_commands.choices(gear=[
        app_commands.Choice(name=f"{g.name} ({g.slot})", value=g.key) for g in GEAR.values()
    ])
    async def armory_equip(self, interaction: discord.Interaction, gear: str) -> None:
        gid, uid = interaction.guild_id, interaction.user.id
        g = GEAR[gear]
        if g.price > 0 and g.key not in await self.db.owned_gear(gid, uid):
            return await interaction.response.send_message(f"You don't own the {g.name} yet. Buy it with `/armory buy`.", ephemeral=True)
        await self.db.equip_gear(gid, uid, g.slot, g.key)
        await interaction.response.send_message(f"🎒 Equipped {g.emoji} **{g.name}**.", ephemeral=True)


    # ============================================================ admin tools
    # These keep working even when battles are switched off (see ADMIN_GROUPS in bot.py).

    army = app_commands.Group(
        name="army",
        description="Admin tools for the battle system.",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    @army.command(name="givexp", description="Give (or with a negative number, take) XP.")
    @app_commands.describe(member="Who", amount="XP to add, e.g. 500 or -200")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def army_givexp(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, -1_000_000, 1_000_000]) -> None:
        old_xp = (await self.db.get_soldier(interaction.guild_id, member.id)).xp
        new_xp = await self.db.add_xp(interaction.guild_id, member.id, amount)
        text = f"✅ {member.mention} now has **{new_xp:,} XP** ({rank_label(rank_index(new_xp))})."
        promo = await self.promotion_message(interaction.guild_id, member, old_xp, new_xp)
        await interaction.response.send_message(text + (f"\n{promo}" if promo else ""))

    @army.command(name="setrank", description="Put a member straight at a rank.")
    @app_commands.describe(member="Who", rank="Their new rank")
    @app_commands.choices(rank=[app_commands.Choice(name=r.name, value=i) for i, r in enumerate(RANKS)])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def army_setrank(self, interaction: discord.Interaction, member: discord.Member, rank: int) -> None:
        await self.db.set_xp(interaction.guild_id, member.id, RANKS[rank].xp)
        await interaction.response.send_message(f"🎖️ {member.mention} is now **{rank_label(rank)}** ({RANKS[rank].xp:,} XP).")

    @army.command(name="givegear", description="Give a member a piece of gear for free (ignores rank locks).")
    @app_commands.describe(member="Who", gear="Which gear")
    @app_commands.choices(gear=[app_commands.Choice(name=f"{g.name} ({g.slot})", value=g.key) for g in GEAR.values() if g.price > 0])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def army_givegear(self, interaction: discord.Interaction, member: discord.Member, gear: str) -> None:
        g = GEAR[gear]
        if not await self.db.give_gear(interaction.guild_id, member.id, g.key):
            return await interaction.response.send_message(f"{member.display_name} already owns the {g.name}.", ephemeral=True)
        await interaction.response.send_message(f"🎁 Gave {member.mention} {g.emoji} **{g.name}**. They can equip it with `/armory equip`.")

    @army.command(name="reset", description="Wipe a member's rank, XP, battle record and gear.")
    @app_commands.describe(member="Who to reset")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def army_reset(self, interaction: discord.Interaction, member: discord.Member) -> None:
        await self.db.reset_soldier(interaction.guild_id, member.id)
        await interaction.response.send_message(f"🧽 {member.mention} is back to {rank_label(0)} with starter gear.")

    @army.command(name="unstick", description="Free a member who's stuck 'already in a battle'.")
    @app_commands.describe(member="Who to free")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def army_unstick(self, interaction: discord.Interaction, member: discord.Member) -> None:
        self.release(interaction.guild_id, member.id)
        await interaction.response.send_message(f"✅ {member.display_name} can start battles again.", ephemeral=True)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Battles(bot))