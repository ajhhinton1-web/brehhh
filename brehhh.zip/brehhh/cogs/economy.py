"""Server economy: coins, daily rewards, jobs, gambling, a shop and robbing.

Every server has its own separate economy. Tweak the numbers in the
SETTINGS section to rebalance things.
"""

import math
import random
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Literal, Optional

import discord
from discord import app_commands
from discord.ext import commands

if TYPE_CHECKING:
    from bot import AdminBot

# ================================================================ SETTINGS

COIN = "🪙"

# The daily reward, work pay and trivia/battle rewards are set per server with
# /setup or /config amount (defaults live in database.py → GuildSettings).
DAILY_STREAK_BONUS = 0.15   # each streak day adds 15% of the daily reward...
DAILY_STREAK_CAP = 7        # ...up to this many days
DAILY_COOLDOWN = 24 * 3600
DAILY_STREAK_WINDOW = 48 * 3600  # claim again within this time to keep the streak

WORK_COOLDOWN = 3600

FISH_COOLDOWN = 1800
ROD_BREAK_CHANCE = 0.04

ROB_COOLDOWN = 3600
ROB_MIN_WALLET = 200        # both robber and victim need at least this much in their wallet
ROB_SUCCESS_CHANCE = 0.40
ROB_STEAL_RANGE = (0.10, 0.35)  # fraction of the victim's wallet stolen on success
ROB_FINE = 0.20             # fraction of the robber's wallet paid to the victim on failure

MIN_BET = 10

JOBS = [
    "delivered pizzas across town",
    "fixed a stranger's computer",
    "streamed to an audience of 3",
    "walked the neighbour's dogs",
    "debugged someone's spaghetti code",
    "ran a lemonade stand",
    "mowed five lawns",
    "won a local karaoke night",
    "tutored a maths student",
    "washed cars in the rain",
    "moderated a very chaotic Discord server",
    "assembled flat-pack furniture without crying",
]

# (emoji, name, weight, min coins, max coins)
FISH_TABLE = [
    ("👢", "an old boot", 15, 1, 10),
    ("🐟", "a fish", 45, 40, 90),
    ("🐠", "a tropical fish", 25, 120, 220),
    ("🐡", "a pufferfish", 10, 200, 350),
    ("🦈", "a SHARK", 4, 600, 1000),
    ("💎", "SUNKEN TREASURE", 1, 2000, 3000),
]

SLOT_SYMBOLS = ["🍒", "🍋", "🍇", "🔔", "⭐", "💎"]
SLOT_TRIPLE_PAYOUT = {"💎": 10, "⭐": 5}  # any other triple pays 3x
SLOT_DEFAULT_TRIPLE = 3
SLOT_PAIR_PAYOUT = 2


@dataclass(frozen=True)
class Item:
    emoji: str
    name: str
    price: int
    description: str


SHOP = {
    "cookie": Item("🍪", "Cookie", 25, "Delicious. Does absolutely nothing."),
    "padlock": Item("🔒", "Padlock", 1500, "Stops the next robbery attempt on you, then breaks."),
    "fishing_rod": Item("🎣", "Fishing Rod", 2500, "Unlocks /fish. Has a small chance to break each use."),
    "trophy": Item("🏆", "Trophy", 50000, "Pure bragging rights. Shows on your /balance."),
}

# ================================================================= helpers


def coins(amount: int) -> str:
    return f"**{amount:,}** {COIN}"


def parse_amount(text: str, available: int) -> Optional[int]:
    """Understands 500, 1,500, 2.5k, 1m, 'all' and 'half'. Returns None if it can't."""
    cleaned = text.strip().lower().replace(",", "").replace("_", "")
    if cleaned in ("all", "max"):
        return available if available > 0 else None
    if cleaned == "half":
        return available // 2 if available >= 2 else None
    multiplier = 1
    if cleaned.endswith("k"):
        multiplier, cleaned = 1_000, cleaned[:-1]
    elif cleaned.endswith("m"):
        multiplier, cleaned = 1_000_000, cleaned[:-1]
    try:
        value = float(cleaned)
    except ValueError:
        return None
    if not math.isfinite(value):
        return None
    amount = int(value * multiplier)
    return amount if amount > 0 else None


def ready_in(timestamp: float) -> str:
    return discord.utils.format_dt(datetime.fromtimestamp(timestamp, timezone.utc), "R")


def spin_slots(rng: random.Random = random) -> tuple:
    """Returns (reels, multiplier). Multiplier is the total paid back, 0 for a loss."""
    reels = [rng.choice(SLOT_SYMBOLS) for _ in range(3)]
    distinct = set(reels)
    if len(distinct) == 1:
        return reels, SLOT_TRIPLE_PAYOUT.get(reels[0], SLOT_DEFAULT_TRIPLE)
    if len(distinct) == 2:
        return reels, SLOT_PAIR_PAYOUT
    return reels, 0


AMOUNT_HELP = "A number, or all / half / 5k"


class Economy(commands.Cog):
    MODULE = "economy"  # can be switched off per server with /config module

    def __init__(self, bot: "AdminBot") -> None:
        self.bot = bot

    @property
    def db(self):
        return self.bot.db

    async def _on_cooldown(self, interaction: discord.Interaction, action: str, seconds: int, verb: str) -> bool:
        """Starts the cooldown and returns False, or tells the user to wait and returns True."""
        ready = await self.db.claim_cooldown(interaction.guild_id, interaction.user.id, action, time.time(), seconds)
        if ready is None:
            return False
        await interaction.response.send_message(f"⏳ You can {verb} again {ready_in(ready)}.", ephemeral=True)
        return True

    # ============================================================== balance

    @app_commands.command(name="balance", description="Check your (or someone's) coins.")
    @app_commands.describe(member="Whose balance to check")
    @app_commands.guild_only()
    async def balance(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        member = member or interaction.user
        account = await self.db.get_account(interaction.guild_id, member.id)
        trophies = await self.db.item_count(interaction.guild_id, member.id, "trophy")

        embed = discord.Embed(title=f"{member.display_name}'s balance", colour=discord.Colour.gold())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="👛 Wallet", value=coins(account.wallet))
        embed.add_field(name="🏦 Bank", value=coins(account.bank))
        embed.add_field(name="💰 Total", value=coins(account.total))
        if trophies:
            embed.description = "🏆" * min(trophies, 20)
        await interaction.response.send_message(embed=embed)

    # ============================================================== earning

    @app_commands.command(name="daily", description="Claim your daily coins. Come back every day to build a streak!")
    @app_commands.guild_only()
    async def daily(self, interaction: discord.Interaction) -> None:
        streak, ready = await self.db.claim_daily(
            interaction.guild_id, interaction.user.id, time.time(), DAILY_COOLDOWN, DAILY_STREAK_WINDOW
        )
        if streak is None:
            return await interaction.response.send_message(
                f"⏳ You've already claimed today. Come back {ready_in(ready)}.", ephemeral=True
            )
        base = (await self.db.get_settings(interaction.guild_id)).daily_amount
        reward = base + round(base * DAILY_STREAK_BONUS) * (min(streak, DAILY_STREAK_CAP) - 1)
        wallet = await self.db.add_wallet(interaction.guild_id, interaction.user.id, reward)
        streak_text = f"🔥 {streak}-day streak!" if streak > 1 else "Come back tomorrow to start a streak."
        await interaction.response.send_message(f"📅 You claimed {coins(reward)}! {streak_text}\nWallet: {coins(wallet)}")

    @app_commands.command(name="work", description="Do a shift and earn some coins (every hour).")
    @app_commands.guild_only()
    async def work(self, interaction: discord.Interaction) -> None:
        if await self._on_cooldown(interaction, "work", WORK_COOLDOWN, "work"):
            return
        settings = await self.db.get_settings(interaction.guild_id)
        pay = random.randint(settings.work_min, max(settings.work_min, settings.work_max))
        await self.db.add_wallet(interaction.guild_id, interaction.user.id, pay)
        await interaction.response.send_message(f"💼 You {random.choice(JOBS)} and earned {coins(pay)}.")

    @app_commands.command(name="fish", description="Go fishing (needs a Fishing Rod from /shop).")
    @app_commands.guild_only()
    async def fish(self, interaction: discord.Interaction) -> None:
        gid, uid = interaction.guild_id, interaction.user.id
        if await self.db.item_count(gid, uid, "fishing_rod") < 1:
            return await interaction.response.send_message(
                "🎣 You need a **Fishing Rod** first. Buy one with `/buy`.", ephemeral=True
            )
        if await self._on_cooldown(interaction, "fish", FISH_COOLDOWN, "fish"):
            return

        emoji, name, _, low, high = random.choices(FISH_TABLE, weights=[f[2] for f in FISH_TABLE])[0]
        value = random.randint(low, high)
        await self.db.add_wallet(gid, uid, value)
        message = f"{emoji} You caught {name} worth {coins(value)}!"
        if random.random() < ROD_BREAK_CHANCE:
            await self.db.remove_item(gid, uid, "fishing_rod")
            message += "\n💥 Oh no, your fishing rod snapped!"
        await interaction.response.send_message(message)

    # ================================================================= bank

    @app_commands.command(name="deposit", description="Move coins from your wallet to the bank (safe from robbers).")
    @app_commands.describe(amount=AMOUNT_HELP)
    @app_commands.guild_only()
    async def deposit(self, interaction: discord.Interaction, amount: str) -> None:
        account = await self.db.get_account(interaction.guild_id, interaction.user.id)
        value = parse_amount(amount, account.wallet)
        if value is None:
            return await interaction.response.send_message(f"Enter a valid amount. Your wallet has {coins(account.wallet)}.", ephemeral=True)
        if not await self.db.deposit(interaction.guild_id, interaction.user.id, value):
            return await interaction.response.send_message(f"You only have {coins(account.wallet)} in your wallet.", ephemeral=True)
        await interaction.response.send_message(f"🏦 Deposited {coins(value)}.")

    @app_commands.command(name="withdraw", description="Move coins from the bank to your wallet.")
    @app_commands.describe(amount=AMOUNT_HELP)
    @app_commands.guild_only()
    async def withdraw(self, interaction: discord.Interaction, amount: str) -> None:
        account = await self.db.get_account(interaction.guild_id, interaction.user.id)
        value = parse_amount(amount, account.bank)
        if value is None:
            return await interaction.response.send_message(f"Enter a valid amount. Your bank has {coins(account.bank)}.", ephemeral=True)
        if not await self.db.withdraw(interaction.guild_id, interaction.user.id, value):
            return await interaction.response.send_message(f"You only have {coins(account.bank)} in the bank.", ephemeral=True)
        await interaction.response.send_message(f"👛 Withdrew {coins(value)}.")

    @app_commands.command(name="pay", description="Give some of your coins to another member.")
    @app_commands.describe(member="Who to pay", amount=AMOUNT_HELP)
    @app_commands.guild_only()
    async def pay(self, interaction: discord.Interaction, member: discord.Member, amount: str) -> None:
        if member.id == interaction.user.id or member.bot:
            return await interaction.response.send_message("You can't pay yourself or a bot.", ephemeral=True)
        account = await self.db.get_account(interaction.guild_id, interaction.user.id)
        value = parse_amount(amount, account.wallet)
        if value is None:
            return await interaction.response.send_message("Enter a valid amount.", ephemeral=True)
        if not await self.db.transfer(interaction.guild_id, interaction.user.id, member.id, value):
            return await interaction.response.send_message(f"You only have {coins(account.wallet)} in your wallet.", ephemeral=True)
        await interaction.response.send_message(f"💸 {interaction.user.mention} paid {member.mention} {coins(value)}.")

    # ================================================================== rob

    @app_commands.command(name="rob", description="Try to steal from someone's wallet. Risky!", extras={"toggle": "robbing"})
    @app_commands.describe(member="Who to rob")
    @app_commands.guild_only()
    async def rob(self, interaction: discord.Interaction, member: discord.Member) -> None:
        gid, robber = interaction.guild_id, interaction.user
        if member.id == robber.id or member.bot:
            return await interaction.response.send_message("Nice try.", ephemeral=True)

        robber_acc = await self.db.get_account(gid, robber.id)
        victim_acc = await self.db.get_account(gid, member.id)
        if robber_acc.wallet < ROB_MIN_WALLET:
            return await interaction.response.send_message(
                f"You need at least {coins(ROB_MIN_WALLET)} in your wallet to risk a robbery.", ephemeral=True
            )
        if victim_acc.wallet < ROB_MIN_WALLET:
            return await interaction.response.send_message(f"{member.display_name} isn't worth robbing right now.", ephemeral=True)
        if await self._on_cooldown(interaction, "rob", ROB_COOLDOWN, "rob"):
            return

        if await self.db.remove_item(gid, member.id, "padlock"):
            return await interaction.response.send_message(
                f"🔒 {member.mention} had a padlock! It broke, and you ran off empty-handed."
            )

        if random.random() < ROB_SUCCESS_CHANCE:
            stolen = max(1, int(victim_acc.wallet * random.uniform(*ROB_STEAL_RANGE)))
            if await self.db.transfer(gid, member.id, robber.id, stolen):
                return await interaction.response.send_message(f"🦹 You robbed {member.mention} and got away with {coins(stolen)}!")
            return await interaction.response.send_message(f"🏃 {member.mention} spent their coins before you got there!")

        fine = max(1, int(robber_acc.wallet * ROB_FINE))
        await self.db.transfer(gid, robber.id, member.id, fine)
        await interaction.response.send_message(f"🚓 You got caught and paid {member.mention} {coins(fine)} in damages.")

    # ============================================================= gambling

    @app_commands.command(name="bet", description="Bet coins on a coin flip. Win double or lose it all.", extras={"toggle": "gambling"})
    @app_commands.describe(amount=AMOUNT_HELP, side="Heads or tails?")
    @app_commands.guild_only()
    async def bet(self, interaction: discord.Interaction, amount: str, side: Literal["heads", "tails"]) -> None:
        gid, uid = interaction.guild_id, interaction.user.id
        account = await self.db.get_account(gid, uid)
        value = parse_amount(amount, account.wallet)
        if value is None or value < MIN_BET:
            return await interaction.response.send_message(f"The minimum bet is {coins(MIN_BET)}.", ephemeral=True)
        if not await self.db.spend_wallet(gid, uid, value):
            return await interaction.response.send_message(f"You only have {coins(account.wallet)} in your wallet.", ephemeral=True)

        result = random.choice(["heads", "tails"])
        if result == side:
            wallet = await self.db.add_wallet(gid, uid, value * 2)
            await interaction.response.send_message(f"🪙 It's **{result}**! You won {coins(value)}. Wallet: {coins(wallet)}")
        else:
            await interaction.response.send_message(f"🪙 It's **{result}**. You lost {coins(value)}.")

    @app_commands.command(name="slots", description="Spin the slot machine.", extras={"toggle": "gambling"})
    @app_commands.describe(amount=AMOUNT_HELP)
    @app_commands.guild_only()
    async def slots(self, interaction: discord.Interaction, amount: str) -> None:
        gid, uid = interaction.guild_id, interaction.user.id
        account = await self.db.get_account(gid, uid)
        value = parse_amount(amount, account.wallet)
        if value is None or value < MIN_BET:
            return await interaction.response.send_message(f"The minimum bet is {coins(MIN_BET)}.", ephemeral=True)
        if not await self.db.spend_wallet(gid, uid, value):
            return await interaction.response.send_message(f"You only have {coins(account.wallet)} in your wallet.", ephemeral=True)

        reels, multiplier = spin_slots()
        line = f"🎰 **[ {' | '.join(reels)} ]**\n"
        if multiplier:
            winnings = value * multiplier
            await self.db.add_wallet(gid, uid, winnings)
            jackpot = " **JACKPOT!**" if multiplier >= 5 else ""
            await interaction.response.send_message(f"{line}You won {coins(winnings - value)} ({multiplier}x)!{jackpot}")
        else:
            await interaction.response.send_message(f"{line}No luck. You lost {coins(value)}.")

    # =========================================================== leaderboard

    @app_commands.command(name="leaderboard", description="The richest members of this server.")
    @app_commands.guild_only()
    async def leaderboard(self, interaction: discord.Interaction) -> None:
        rows = await self.db.leaderboard(interaction.guild_id, 10)
        if not rows:
            return await interaction.response.send_message("Nobody has any coins yet. Try `/daily`!")
        medals = ["🥇", "🥈", "🥉"]
        lines = [
            f"{medals[i] if i < 3 else f'`#{i + 1}`'} <@{row['user_id']}> — {coins(row['total'])}"
            for i, row in enumerate(rows)
        ]
        embed = discord.Embed(title=f"💰 Richest in {interaction.guild.name}", description="\n".join(lines), colour=discord.Colour.gold())
        await interaction.response.send_message(embed=embed)

    # ================================================================= shop

    @app_commands.command(name="shop", description="See what's for sale.")
    @app_commands.guild_only()
    async def shop(self, interaction: discord.Interaction) -> None:
        embed = discord.Embed(title="🛒 Shop", description="Buy with `/buy`.", colour=discord.Colour.blurple())
        for item in SHOP.values():
            embed.add_field(name=f"{item.emoji} {item.name} — {item.price:,} {COIN}", value=item.description, inline=False)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="buy", description="Buy something from the shop.")
    @app_commands.describe(item="What to buy", quantity="How many")
    @app_commands.choices(
        item=[app_commands.Choice(name=f"{i.name} ({i.price:,} coins)", value=key) for key, i in SHOP.items()]
    )
    @app_commands.guild_only()
    async def buy(self, interaction: discord.Interaction, item: str, quantity: app_commands.Range[int, 1, 100] = 1) -> None:
        product = SHOP[item]
        total = product.price * quantity
        if not await self.db.buy_item(interaction.guild_id, interaction.user.id, item, quantity, total):
            return await interaction.response.send_message(
                f"That costs {coins(total)}. You don't have enough in your wallet.", ephemeral=True
            )
        await interaction.response.send_message(f"🛍️ You bought {quantity}× {product.emoji} **{product.name}** for {coins(total)}.")

    @app_commands.command(name="inventory", description="See your (or someone's) items.")
    @app_commands.describe(member="Whose inventory to view")
    @app_commands.guild_only()
    async def inventory(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        member = member or interaction.user
        items = await self.db.get_inventory(interaction.guild_id, member.id)
        if not items:
            return await interaction.response.send_message(f"{member.display_name} doesn't own anything yet. Check `/shop`!")
        lines = []
        for key, qty in items.items():
            product = SHOP.get(key)
            label = f"{product.emoji} {product.name}" if product else key
            lines.append(f"{label} × **{qty}**")
        embed = discord.Embed(title=f"🎒 {member.display_name}'s inventory", description="\n".join(lines), colour=discord.Colour.blurple())
        await interaction.response.send_message(embed=embed)

    # ========================================================== admin tools
    # These keep working even when the economy is switched off (see ADMIN_GROUPS in bot.py).

    eco = app_commands.Group(
        name="eco",
        description="Admin tools for the economy.",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    async def _eco_log(self, interaction: discord.Interaction, action: str, member: discord.abc.User, detail: str) -> None:
        embed = discord.Embed(title=f"Economy: {action}", colour=discord.Colour.gold(), timestamp=discord.utils.utcnow())
        embed.add_field(name="Member", value=f"{member.mention} (`{member.id}`)")
        embed.add_field(name="Admin", value=interaction.user.mention)
        embed.add_field(name="Details", value=detail, inline=False)
        await self.bot.send_modlog(interaction.guild, embed)

    @eco.command(name="give", description="Give a member coins (created from nothing).")
    @app_commands.describe(member="Who gets the coins", amount="How many")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eco_give(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        wallet = await self.db.add_wallet(interaction.guild_id, member.id, amount)
        await interaction.response.send_message(f"✅ Gave {member.mention} {coins(amount)}. Their wallet: {coins(wallet)}")
        await self._eco_log(interaction, "coins given", member, f"+{amount:,} → wallet {wallet:,}")

    @eco.command(name="take", description="Remove coins from a member's wallet.")
    @app_commands.describe(member="Who loses the coins", amount="How many")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eco_take(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 1, 1_000_000_000]) -> None:
        wallet = await self.db.add_wallet(interaction.guild_id, member.id, -amount)
        await interaction.response.send_message(f"✅ Took up to {coins(amount)} from {member.mention}. Their wallet: {coins(wallet)}")
        await self._eco_log(interaction, "coins taken", member, f"-{amount:,} → wallet {wallet:,}")

    @eco.command(name="set", description="Set a member's wallet to an exact amount.")
    @app_commands.describe(member="Whose wallet", amount="New wallet amount")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eco_set(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int, 0, 1_000_000_000]) -> None:
        await self.db.set_wallet(interaction.guild_id, member.id, amount)
        await interaction.response.send_message(f"✅ Set {member.mention}'s wallet to {coins(amount)}.")
        await self._eco_log(interaction, "wallet set", member, f"wallet = {amount:,}")

    @eco.command(name="giveitem", description="Give a member a shop item for free.")
    @app_commands.describe(member="Who gets it", item="Which item", quantity="How many")
    @app_commands.choices(item=[app_commands.Choice(name=i.name, value=key) for key, i in SHOP.items()])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eco_giveitem(self, interaction: discord.Interaction, member: discord.Member, item: str, quantity: app_commands.Range[int, 1, 1000] = 1) -> None:
        await self.db.give_item(interaction.guild_id, member.id, item, quantity)
        product = SHOP[item]
        await interaction.response.send_message(f"🎁 Gave {member.mention} {quantity}× {product.emoji} **{product.name}**.")
        await self._eco_log(interaction, "item given", member, f"{quantity}× {product.name}")

    @eco.command(name="resetcooldowns", description="Let a member use /daily, /work, /rob etc. again right away.")
    @app_commands.describe(member="Whose cooldowns to clear")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eco_resetcooldowns(self, interaction: discord.Interaction, member: discord.Member) -> None:
        await self.db.reset_cooldowns(interaction.guild_id, member.id)
        await interaction.response.send_message(f"⏱️ Cleared all cooldowns for {member.mention}.", ephemeral=True)

    @eco.command(name="reset", description="Wipe one member's coins, items and cooldowns.")
    @app_commands.describe(member="Whose economy data to wipe")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def eco_reset(self, interaction: discord.Interaction, member: discord.Member) -> None:
        await self.db.reset_economy_user(interaction.guild_id, member.id)
        await interaction.response.send_message(f"🧽 Reset {member.mention}'s economy data.")
        await self._eco_log(interaction, "member reset", member, "Wallet, bank, items and cooldowns wiped")

    @eco.command(name="wipe", description="Reset the ENTIRE server economy. Asks for confirmation.")
    @app_commands.checks.has_permissions(administrator=True)
    async def eco_wipe(self, interaction: discord.Interaction) -> None:
        async def do_wipe(button_interaction: discord.Interaction) -> None:
            removed = await self.db.wipe_economy(interaction.guild_id)
            await button_interaction.response.edit_message(
                content=f"💥 Economy wiped. {removed} account(s) reset to zero.", embed=None, view=None
            )
            await self._eco_log(interaction, "SERVER ECONOMY WIPED", interaction.user, f"{removed} accounts removed")

        view = ConfirmView(interaction.user.id, do_wipe)
        await interaction.response.send_message(
            "⚠️ This deletes **every** member's coins, bank, items and cooldowns in this server. It can't be undone.",
            view=view,
            ephemeral=True,
        )


class ConfirmView(discord.ui.View):
    """A 'Yes, do it' / 'Cancel' prompt that only the person who asked can answer."""

    def __init__(self, user_id: int, on_confirm, timeout: float = 30) -> None:
        super().__init__(timeout=timeout)
        self.user_id = user_id
        self.on_confirm = on_confirm

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.user_id

    @discord.ui.button(label="Yes, do it", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.stop()
        await self.on_confirm(interaction)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.stop()
        await interaction.response.edit_message(content="Cancelled. Nothing was changed.", view=None)


async def setup(bot: "AdminBot") -> None:
    await bot.add_cog(Economy(bot))