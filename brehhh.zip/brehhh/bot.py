"""Entry point: python bot.py"""

import logging
import os
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from database import ADMIN_GROUPS, MODULES, Database

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
# Optional: set GUILD_ID to your test server's ID so slash commands appear instantly there.
GUILD_ID = os.getenv("GUILD_ID")
DATABASE_PATH = os.getenv("DATABASE_PATH", "adminbot.db")

EXTENSIONS = (
    "cogs.moderation",
    "cogs.channels",
    "cogs.admin",
    "cogs.logs",
    "cogs.economy",
    "cogs.fun",
    "cogs.battle",
    "cogs.config",
)

log = logging.getLogger("adminbot")


async def reply_ephemeral(interaction: discord.Interaction, message: str) -> None:
    """Send a private reply whether or not the interaction was already answered/deferred."""
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)


def _pretty_perms(perms) -> str:
    return ", ".join(p.replace("_", " ").title() for p in perms)


class AdminTree(app_commands.CommandTree):
    """Command tree with one central error handler and the per-server module switches."""

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        """Runs before every slash command. Blocks game commands an admin has switched off."""
        if interaction.type is not discord.InteractionType.application_command or interaction.guild_id is None:
            return True
        command = interaction.command
        module = getattr(getattr(command, "binding", None), "MODULE", None)
        if command is None or module is None:
            return True  # moderation/admin cogs are never blocked
        root = command.root_parent.name if getattr(command, "root_parent", None) else command.name
        if root in ADMIN_GROUPS:
            return True

        settings = await self.client.db.get_settings(interaction.guild_id)
        reason = None
        for switch in (module, getattr(command, "extras", {}).get("toggle")):
            if switch and not getattr(settings, switch, True):
                reason = f"{MODULES[switch]} is turned off in this server."
                break
        if reason is None and root in settings.disabled_commands:
            reason = f"`/{root}` has been disabled by the server admins."
        if (
            reason is None
            and settings.games_channel_id
            and interaction.channel_id != settings.games_channel_id
            and not interaction.permissions.manage_guild
        ):
            reason = f"Game commands only work in <#{settings.games_channel_id}>."

        if reason:
            await interaction.response.send_message(f"🚫 {reason}", ephemeral=True)
            return False
        return True

    async def on_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
        if isinstance(error, app_commands.MissingPermissions):
            msg = f"You need the **{_pretty_perms(error.missing_permissions)}** permission(s) to do that."
        elif isinstance(error, app_commands.BotMissingPermissions):
            msg = f"I'm missing the **{_pretty_perms(error.missing_permissions)}** permission(s)."
        elif isinstance(error, app_commands.CommandOnCooldown):
            msg = f"Slow down — try again in {error.retry_after:.1f}s."
        elif isinstance(error, app_commands.NoPrivateMessage):
            msg = "This command only works inside a server."
        elif isinstance(error, app_commands.CheckFailure):
            msg = "You can't use this command."
        else:
            original = getattr(error, "original", error)
            if isinstance(original, discord.Forbidden):
                msg = "Discord blocked that action. Check my permissions and that my role is above the target's."
            else:
                name = interaction.command.qualified_name if interaction.command else "unknown"
                log.error("Unhandled error in /%s", name, exc_info=original)
                msg = "Something went wrong running that command. The error has been logged."

        try:
            await reply_ephemeral(interaction, msg)
        except discord.HTTPException:
            pass  # interaction expired; nothing else we can do


class AdminBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True          # privileged: member lookups, join/leave logs
        intents.message_content = True  # privileged: content in edit/delete logs
        super().__init__(
            command_prefix=commands.when_mentioned,  # slash commands only; no prefix needed
            intents=intents,
            tree_cls=AdminTree,
            help_command=None,
        )
        self.db = Database(DATABASE_PATH)

    async def setup_hook(self) -> None:
        await self.db.connect()
        for ext in EXTENSIONS:
            await self.load_extension(ext)
            log.info("Loaded %s", ext)

        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Synced %d commands to guild %s", len(synced), GUILD_ID)
        else:
            synced = await self.tree.sync()
            log.info("Synced %d global commands", len(synced))

    async def on_ready(self) -> None:
        log.info("Logged in as %s (ID: %s) in %d server(s)", self.user, self.user.id, len(self.guilds))
        await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="the server"))

    async def close(self) -> None:
        await self.db.close()
        await super().close()

    async def send_modlog(self, guild: discord.Guild, embed: discord.Embed) -> None:
        """Post an embed to the server's configured log channel, if there is one."""
        channel_id: Optional[int] = await self.db.get_log_channel(guild.id)
        if channel_id is None:
            return
        channel = guild.get_channel(channel_id)
        if not isinstance(channel, discord.TextChannel):
            return
        try:
            await channel.send(embed=embed)
        except discord.HTTPException as exc:
            log.warning("Couldn't post to log channel %s in %s: %s", channel_id, guild.id, exc)


def main() -> None:
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN is not set. Copy .env.example to .env and add your bot token.")
    bot = AdminBot()
    bot.run(TOKEN, root_logger=True)


if __name__ == "__main__":
    main()