"""Shared helpers: duration parsing, role-hierarchy checks, embeds."""

import re
from datetime import timedelta
from typing import Optional

import discord

_DURATION_PART = re.compile(r"(\d+)([smhdw])")
_UNIT_SECONDS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_duration(text: str) -> Optional[timedelta]:
    """Turn '10m', '1h30m', '2d 12h' into a timedelta. Returns None if invalid."""
    cleaned = text.lower().replace(" ", "")
    if not cleaned:
        return None
    total = 0
    pos = 0
    for match in _DURATION_PART.finditer(cleaned):
        if match.start() != pos:  # junk between parts, e.g. '10x5m'
            return None
        total += int(match.group(1)) * _UNIT_SECONDS[match.group(2)]
        pos = match.end()
    if pos != len(cleaned) or total <= 0:
        return None
    return timedelta(seconds=total)


def format_duration(delta: timedelta) -> str:
    seconds = int(delta.total_seconds())
    parts = []
    for name, size in (("d", 86400), ("h", 3600), ("m", 60), ("s", 1)):
        value, seconds = divmod(seconds, size)
        if value:
            parts.append(f"{value}{name}")
    return " ".join(parts) or "0s"


def hierarchy_error(actor: discord.Member, target: discord.Member) -> Optional[str]:
    """Return why `actor` can't moderate `target`, or None if they can.

    Discord itself enforces the bot's side of this, but checking first gives
    a clear message instead of a generic 'Forbidden' error.
    """
    guild = target.guild
    if target.id == actor.id:
        return "You can't use this on yourself."
    if target.id == guild.me.id:
        return "I can't moderate myself."
    if target.id == guild.owner_id:
        return "You can't moderate the server owner."
    if actor.id != guild.owner_id and target.top_role >= actor.top_role:
        return "That member's top role is equal to or higher than yours."
    if target.top_role >= guild.me.top_role:
        return "That member's top role is equal to or higher than mine. Move my role higher in Server Settings → Roles."
    return None


def truncate(text: str, limit: int = 1024) -> str:
    return text if len(text) <= limit else text[: limit - 1] + "…"


def action_embed(
    action: str,
    target: discord.abc.User,
    moderator: discord.abc.User,
    reason: Optional[str],
    colour: discord.Colour,
) -> discord.Embed:
    """Standard embed used for the mod-log channel."""
    embed = discord.Embed(title=action, colour=colour, timestamp=discord.utils.utcnow())
    embed.add_field(name="User", value=f"{target.mention} (`{target.id}`)")
    embed.add_field(name="Moderator", value=moderator.mention)
    if reason:
        embed.add_field(name="Reason", value=truncate(reason), inline=False)
    embed.set_thumbnail(url=target.display_avatar.url)
    return embed