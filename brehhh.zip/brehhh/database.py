"""SQLite storage for warnings, per-server settings and the economy."""

import asyncio
import json
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from typing import Dict, List, NamedTuple, Optional

import aiosqlite

SCHEMA = """
CREATE TABLE IF NOT EXISTS warnings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id     INTEGER NOT NULL,
    user_id      INTEGER NOT NULL,
    moderator_id INTEGER NOT NULL,
    reason       TEXT    NOT NULL,
    created_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_warnings_member ON warnings (guild_id, user_id);

CREATE TABLE IF NOT EXISTS guild_config (
    guild_id       INTEGER PRIMARY KEY,
    log_channel_id INTEGER
);

CREATE TABLE IF NOT EXISTS economy (
    guild_id     INTEGER NOT NULL,
    user_id      INTEGER NOT NULL,
    wallet       INTEGER NOT NULL DEFAULT 0,
    bank         INTEGER NOT NULL DEFAULT 0,
    daily_streak INTEGER NOT NULL DEFAULT 0,
    last_daily   REAL    NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS cooldowns (
    guild_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    action   TEXT    NOT NULL,
    ready_at REAL    NOT NULL,
    PRIMARY KEY (guild_id, user_id, action)
);

CREATE TABLE IF NOT EXISTS inventory (
    guild_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    item     TEXT    NOT NULL,
    quantity INTEGER NOT NULL,
    PRIMARY KEY (guild_id, user_id, item)
);

CREATE TABLE IF NOT EXISTS military (
    guild_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    xp       INTEGER NOT NULL DEFAULT 0,
    wins     INTEGER NOT NULL DEFAULT 0,
    losses   INTEGER NOT NULL DEFAULT 0,
    weapon   TEXT    NOT NULL DEFAULT 'pistol',
    armor    TEXT    NOT NULL DEFAULT 'none',
    support  TEXT    NOT NULL DEFAULT 'grenade',
    PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE IF NOT EXISTS gear_owned (
    guild_id INTEGER NOT NULL,
    user_id  INTEGER NOT NULL,
    gear     TEXT    NOT NULL,
    PRIMARY KEY (guild_id, user_id, gear)
);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER PRIMARY KEY,
    data     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS custom_content (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL,
    kind     TEXT    NOT NULL,
    data     TEXT    NOT NULL
);
"""

GEAR_SLOTS = ("weapon", "armor", "support")

# Feature switches an admin can flip with /config module or /setup.
MODULES = {
    "economy": "💰 Economy",
    "gambling": "🎰 Gambling (/bet, /slots)",
    "robbing": "🦹 Robbing (/rob)",
    "fun": "🎉 Fun",
    "battles": "⚔️ Battles",
}

# Admin command groups inside game cogs. They keep working even if that game is switched off,
# and can't be disabled with /config command.
ADMIN_GROUPS = {"eco", "army"}

# Numbers an admin can change with /config amount or /setup: key -> (label, min, max)
AMOUNTS = {
    "daily_amount": ("Daily reward", 1, 1_000_000),
    "work_min": ("Work pay (min)", 1, 1_000_000),
    "work_max": ("Work pay (max)", 1, 1_000_000),
    "trivia_reward": ("Trivia reward", 0, 1_000_000),
    "battle_win_coins": ("Battle win bonus", 0, 1_000_000),
}


@dataclass
class GuildSettings:
    economy: bool = True
    gambling: bool = True
    robbing: bool = True
    fun: bool = True
    battles: bool = True
    games_channel_id: Optional[int] = None  # if set, game commands only work there
    disabled_commands: List[str] = field(default_factory=list)
    daily_amount: int = 500
    work_min: int = 100
    work_max: int = 300
    trivia_reward: int = 50
    battle_win_coins: int = 100

    @classmethod
    def from_json(cls, text: str) -> "GuildSettings":
        data = json.loads(text)
        known = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in data.items() if k in known})

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    def copy(self) -> "GuildSettings":
        return GuildSettings.from_json(self.to_json())


class Soldier(NamedTuple):
    xp: int
    wins: int
    losses: int
    weapon: str
    armor: str
    support: str


DEFAULT_SOLDIER = Soldier(0, 0, 0, "pistol", "none", "grenade")


class Account(NamedTuple):
    wallet: int
    bank: int

    @property
    def total(self) -> int:
        return self.wallet + self.bank


class Database:
    def __init__(self, path: str) -> None:
        self.path = path
        self._conn: Optional[aiosqlite.Connection] = None
        # Read on every message edit/delete or command, so keep them in memory.
        self._log_channel_cache: Dict[int, Optional[int]] = {}
        self._settings_cache: Dict[int, GuildSettings] = {}
        # Serialises multi-step money operations so two commands can't
        # spend the same coins at the same time.
        self._lock = asyncio.Lock()

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database.connect() has not been called")
        return self._conn

    async def connect(self) -> None:
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.executescript(SCHEMA)  # safe on an existing database: only adds missing tables
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    # ================================================================ warnings

    async def add_warning(self, guild_id: int, user_id: int, moderator_id: int, reason: str) -> int:
        cur = await self.conn.execute(
            "INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (guild_id, user_id, moderator_id, reason, datetime.now(timezone.utc).isoformat()),
        )
        await self.conn.commit()
        return cur.lastrowid

    async def get_warnings(self, guild_id: int, user_id: int) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY id",
            (guild_id, user_id),
        )
        return list(await cur.fetchall())

    async def count_warnings(self, guild_id: int, user_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT COUNT(*) FROM warnings WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )
        row = await cur.fetchone()
        return row[0]

    async def delete_warning(self, guild_id: int, warning_id: int) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM warnings WHERE guild_id = ? AND id = ?", (guild_id, warning_id)
        )
        await self.conn.commit()
        return cur.rowcount > 0

    async def clear_warnings(self, guild_id: int, user_id: int) -> int:
        cur = await self.conn.execute(
            "DELETE FROM warnings WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        )
        await self.conn.commit()
        return cur.rowcount

    # ========================================================= server settings

    async def set_log_channel(self, guild_id: int, channel_id: Optional[int]) -> None:
        await self.conn.execute(
            "INSERT INTO guild_config (guild_id, log_channel_id) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET log_channel_id = excluded.log_channel_id",
            (guild_id, channel_id),
        )
        await self.conn.commit()
        self._log_channel_cache[guild_id] = channel_id

    async def get_log_channel(self, guild_id: int) -> Optional[int]:
        if guild_id in self._log_channel_cache:
            return self._log_channel_cache[guild_id]
        cur = await self.conn.execute(
            "SELECT log_channel_id FROM guild_config WHERE guild_id = ?", (guild_id,)
        )
        row = await cur.fetchone()
        value = row[0] if row else None
        self._log_channel_cache[guild_id] = value
        return value

    async def get_settings(self, guild_id: int) -> GuildSettings:
        """Returns a copy, so changing it does nothing until you call save_settings()."""
        if guild_id not in self._settings_cache:
            cur = await self.conn.execute("SELECT data FROM guild_settings WHERE guild_id = ?", (guild_id,))
            row = await cur.fetchone()
            self._settings_cache[guild_id] = GuildSettings.from_json(row[0]) if row else GuildSettings()
        return self._settings_cache[guild_id].copy()

    async def save_settings(self, guild_id: int, settings: GuildSettings) -> None:
        await self.conn.execute(
            "INSERT INTO guild_settings (guild_id, data) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET data = excluded.data",
            (guild_id, settings.to_json()),
        )
        await self.conn.commit()
        self._settings_cache[guild_id] = settings.copy()

    # ===================================================== custom fun content

    async def add_content(self, guild_id: int, kind: str, data: dict) -> int:
        cur = await self.conn.execute(
            "INSERT INTO custom_content (guild_id, kind, data) VALUES (?, ?, ?)",
            (guild_id, kind, json.dumps(data)),
        )
        await self.conn.commit()
        return cur.lastrowid

    async def list_content(self, guild_id: int, kind: Optional[str] = None) -> List[dict]:
        if kind is None:
            cur = await self.conn.execute(
                "SELECT id, kind, data FROM custom_content WHERE guild_id = ? ORDER BY id", (guild_id,)
            )
        else:
            cur = await self.conn.execute(
                "SELECT id, kind, data FROM custom_content WHERE guild_id = ? AND kind = ? ORDER BY id",
                (guild_id, kind),
            )
        return [{"id": r[0], "kind": r[1], **json.loads(r[2])} for r in await cur.fetchall()]

    async def delete_content(self, guild_id: int, content_id: int) -> bool:
        cur = await self.conn.execute(
            "DELETE FROM custom_content WHERE guild_id = ? AND id = ?", (guild_id, content_id)
        )
        await self.conn.commit()
        return cur.rowcount > 0

    # ================================================================= economy
    # Methods starting with _ assume the caller already holds self._lock.

    async def _ensure_account(self, guild_id: int, user_id: int) -> None:
        await self.conn.execute(
            "INSERT OR IGNORE INTO economy (guild_id, user_id) VALUES (?, ?)", (guild_id, user_id)
        )

    async def _wallet(self, guild_id: int, user_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT wallet FROM economy WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        )
        row = await cur.fetchone()
        return row[0] if row else 0

    async def get_account(self, guild_id: int, user_id: int) -> Account:
        cur = await self.conn.execute(
            "SELECT wallet, bank FROM economy WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        )
        row = await cur.fetchone()
        return Account(row[0], row[1]) if row else Account(0, 0)

    async def add_wallet(self, guild_id: int, user_id: int, delta: int) -> int:
        """Add (or with a negative delta, remove) coins. Never goes below 0. Returns the new wallet."""
        async with self._lock:
            await self._ensure_account(guild_id, user_id)
            await self.conn.execute(
                "UPDATE economy SET wallet = MAX(wallet + ?, 0) WHERE guild_id = ? AND user_id = ?",
                (delta, guild_id, user_id),
            )
            await self.conn.commit()
            return await self._wallet(guild_id, user_id)

    async def _spend(self, guild_id: int, user_id: int, amount: int) -> bool:
        cur = await self.conn.execute(
            "UPDATE economy SET wallet = wallet - ? WHERE guild_id = ? AND user_id = ? AND wallet >= ?",
            (amount, guild_id, user_id, amount),
        )
        return cur.rowcount > 0

    async def spend_wallet(self, guild_id: int, user_id: int, amount: int) -> bool:
        """Take coins from the wallet only if there are enough. Returns False otherwise."""
        async with self._lock:
            ok = await self._spend(guild_id, user_id, amount)
            await self.conn.commit()
            return ok

    async def deposit(self, guild_id: int, user_id: int, amount: int) -> bool:
        async with self._lock:
            cur = await self.conn.execute(
                "UPDATE economy SET wallet = wallet - ?, bank = bank + ? "
                "WHERE guild_id = ? AND user_id = ? AND wallet >= ?",
                (amount, amount, guild_id, user_id, amount),
            )
            await self.conn.commit()
            return cur.rowcount > 0

    async def withdraw(self, guild_id: int, user_id: int, amount: int) -> bool:
        async with self._lock:
            cur = await self.conn.execute(
                "UPDATE economy SET wallet = wallet + ?, bank = bank - ? "
                "WHERE guild_id = ? AND user_id = ? AND bank >= ?",
                (amount, amount, guild_id, user_id, amount),
            )
            await self.conn.commit()
            return cur.rowcount > 0

    async def transfer(self, guild_id: int, from_id: int, to_id: int, amount: int) -> bool:
        """Move coins wallet → wallet. Returns False if the sender can't afford it."""
        async with self._lock:
            if not await self._spend(guild_id, from_id, amount):
                return False
            await self._ensure_account(guild_id, to_id)
            await self.conn.execute(
                "UPDATE economy SET wallet = wallet + ? WHERE guild_id = ? AND user_id = ?",
                (amount, guild_id, to_id),
            )
            await self.conn.commit()
            return True

    async def claim_daily(self, guild_id: int, user_id: int, now: float, cooldown: float, streak_window: float):
        """Returns (streak, None) if claimed, or (None, ready_at) if still on cooldown."""
        async with self._lock:
            await self._ensure_account(guild_id, user_id)
            cur = await self.conn.execute(
                "SELECT daily_streak, last_daily FROM economy WHERE guild_id = ? AND user_id = ?",
                (guild_id, user_id),
            )
            streak, last = await cur.fetchone()
            if now - last < cooldown:
                return None, last + cooldown
            streak = streak + 1 if now - last < streak_window else 1
            await self.conn.execute(
                "UPDATE economy SET daily_streak = ?, last_daily = ? WHERE guild_id = ? AND user_id = ?",
                (streak, now, guild_id, user_id),
            )
            await self.conn.commit()
            return streak, None

    async def set_wallet(self, guild_id: int, user_id: int, amount: int) -> None:
        async with self._lock:
            await self._ensure_account(guild_id, user_id)
            await self.conn.execute(
                "UPDATE economy SET wallet = ? WHERE guild_id = ? AND user_id = ?", (amount, guild_id, user_id)
            )
            await self.conn.commit()

    async def give_item(self, guild_id: int, user_id: int, item: str, quantity: int) -> None:
        async with self._lock:
            await self._add_item(guild_id, user_id, item, quantity)
            await self.conn.commit()

    async def reset_cooldowns(self, guild_id: int, user_id: int) -> int:
        async with self._lock:
            cur = await self.conn.execute(
                "DELETE FROM cooldowns WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
            )
            await self.conn.execute(
                "UPDATE economy SET last_daily = 0 WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
            )
            await self.conn.commit()
            return cur.rowcount

    async def reset_economy_user(self, guild_id: int, user_id: int) -> None:
        """Wipe one member's coins, items, cooldowns and daily streak."""
        async with self._lock:
            for table in ("economy", "inventory", "cooldowns"):
                await self.conn.execute(f"DELETE FROM {table} WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))
            await self.conn.commit()

    async def wipe_economy(self, guild_id: int) -> int:
        """Wipe the whole server's economy. Returns how many accounts were removed."""
        async with self._lock:
            cur = await self.conn.execute("DELETE FROM economy WHERE guild_id = ?", (guild_id,))
            removed = cur.rowcount
            await self.conn.execute("DELETE FROM inventory WHERE guild_id = ?", (guild_id,))
            await self.conn.execute("DELETE FROM cooldowns WHERE guild_id = ?", (guild_id,))
            await self.conn.commit()
            return removed

    async def leaderboard(self, guild_id: int, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT user_id, wallet, bank, wallet + bank AS total FROM economy "
            "WHERE guild_id = ? AND wallet + bank > 0 ORDER BY total DESC LIMIT ?",
            (guild_id, limit),
        )
        return list(await cur.fetchall())

    # --------------------------------------------------------------- cooldowns

    async def claim_cooldown(self, guild_id: int, user_id: int, action: str, now: float, seconds: float) -> Optional[float]:
        """Start a cooldown. Returns None if it started, or the time it's ready if still cooling down."""
        async with self._lock:
            cur = await self.conn.execute(
                "SELECT ready_at FROM cooldowns WHERE guild_id = ? AND user_id = ? AND action = ?",
                (guild_id, user_id, action),
            )
            row = await cur.fetchone()
            if row and row[0] > now:
                return row[0]
            await self.conn.execute(
                "INSERT INTO cooldowns (guild_id, user_id, action, ready_at) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(guild_id, user_id, action) DO UPDATE SET ready_at = excluded.ready_at",
                (guild_id, user_id, action, now + seconds),
            )
            await self.conn.commit()
            return None

    # --------------------------------------------------------------- inventory

    async def _add_item(self, guild_id: int, user_id: int, item: str, quantity: int) -> None:
        await self.conn.execute(
            "INSERT INTO inventory (guild_id, user_id, item, quantity) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(guild_id, user_id, item) DO UPDATE SET quantity = quantity + excluded.quantity",
            (guild_id, user_id, item, quantity),
        )

    async def buy_item(self, guild_id: int, user_id: int, item: str, quantity: int, total_price: int) -> bool:
        """Charge the wallet and add the item in one step. Returns False if they can't afford it."""
        async with self._lock:
            if not await self._spend(guild_id, user_id, total_price):
                return False
            await self._add_item(guild_id, user_id, item, quantity)
            await self.conn.commit()
            return True

    async def remove_item(self, guild_id: int, user_id: int, item: str, quantity: int = 1) -> bool:
        async with self._lock:
            cur = await self.conn.execute(
                "UPDATE inventory SET quantity = quantity - ? "
                "WHERE guild_id = ? AND user_id = ? AND item = ? AND quantity >= ?",
                (quantity, guild_id, user_id, item, quantity),
            )
            await self.conn.execute("DELETE FROM inventory WHERE quantity <= 0")
            await self.conn.commit()
            return cur.rowcount > 0

    async def item_count(self, guild_id: int, user_id: int, item: str) -> int:
        cur = await self.conn.execute(
            "SELECT quantity FROM inventory WHERE guild_id = ? AND user_id = ? AND item = ?",
            (guild_id, user_id, item),
        )
        row = await cur.fetchone()
        return row[0] if row else 0

    async def get_inventory(self, guild_id: int, user_id: int) -> Dict[str, int]:
        cur = await self.conn.execute(
            "SELECT item, quantity FROM inventory WHERE guild_id = ? AND user_id = ? ORDER BY item",
            (guild_id, user_id),
        )
        return {row[0]: row[1] for row in await cur.fetchall()}

    # ================================================================ military

    async def get_soldier(self, guild_id: int, user_id: int) -> Soldier:
        cur = await self.conn.execute(
            "SELECT xp, wins, losses, weapon, armor, support FROM military WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )
        row = await cur.fetchone()
        return Soldier(*row) if row else DEFAULT_SOLDIER

    async def add_xp(self, guild_id: int, user_id: int, xp: int, won: Optional[bool] = None) -> int:
        """Add XP (and a win/loss if `won` is given). Returns the new XP total."""
        async with self._lock:
            await self.conn.execute(
                "INSERT OR IGNORE INTO military (guild_id, user_id) VALUES (?, ?)", (guild_id, user_id)
            )
            await self.conn.execute(
                "UPDATE military SET xp = MAX(xp + ?, 0), wins = wins + ?, losses = losses + ? "
                "WHERE guild_id = ? AND user_id = ?",
                (xp, 1 if won is True else 0, 1 if won is False else 0, guild_id, user_id),
            )
            await self.conn.commit()
            cur = await self.conn.execute(
                "SELECT xp FROM military WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
            )
            return (await cur.fetchone())[0]

    async def owned_gear(self, guild_id: int, user_id: int) -> set:
        cur = await self.conn.execute(
            "SELECT gear FROM gear_owned WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        )
        return {row[0] for row in await cur.fetchall()}

    async def _equip(self, guild_id: int, user_id: int, slot: str, gear: str) -> None:
        if slot not in GEAR_SLOTS:  # slot becomes a column name, so only allow known values
            raise ValueError(f"Unknown gear slot {slot!r}")
        await self.conn.execute(
            "INSERT OR IGNORE INTO military (guild_id, user_id) VALUES (?, ?)", (guild_id, user_id)
        )
        await self.conn.execute(
            f"UPDATE military SET {slot} = ? WHERE guild_id = ? AND user_id = ?", (gear, guild_id, user_id)
        )

    async def buy_gear(self, guild_id: int, user_id: int, gear: str, slot: str, price: int) -> bool:
        """Pay for gear, add it to the soldier's collection and equip it. False if they can't afford it."""
        async with self._lock:
            if not await self._spend(guild_id, user_id, price):
                return False
            await self.conn.execute(
                "INSERT OR IGNORE INTO gear_owned (guild_id, user_id, gear) VALUES (?, ?, ?)",
                (guild_id, user_id, gear),
            )
            await self._equip(guild_id, user_id, slot, gear)
            await self.conn.commit()
            return True

    async def equip_gear(self, guild_id: int, user_id: int, slot: str, gear: str) -> None:
        async with self._lock:
            await self._equip(guild_id, user_id, slot, gear)
            await self.conn.commit()

    async def set_xp(self, guild_id: int, user_id: int, xp: int) -> None:
        async with self._lock:
            await self.conn.execute(
                "INSERT OR IGNORE INTO military (guild_id, user_id) VALUES (?, ?)", (guild_id, user_id)
            )
            await self.conn.execute(
                "UPDATE military SET xp = ? WHERE guild_id = ? AND user_id = ?", (xp, guild_id, user_id)
            )
            await self.conn.commit()

    async def give_gear(self, guild_id: int, user_id: int, gear: str) -> bool:
        """Add gear to a soldier's collection for free. False if they already had it."""
        async with self._lock:
            cur = await self.conn.execute(
                "INSERT OR IGNORE INTO gear_owned (guild_id, user_id, gear) VALUES (?, ?, ?)",
                (guild_id, user_id, gear),
            )
            await self.conn.commit()
            return cur.rowcount > 0

    async def reset_soldier(self, guild_id: int, user_id: int) -> None:
        """Wipe one member's rank, XP, record and gear."""
        async with self._lock:
            await self.conn.execute("DELETE FROM military WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))
            await self.conn.execute("DELETE FROM gear_owned WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))
            await self.conn.commit()

    async def military_leaderboard(self, guild_id: int, limit: int = 10) -> List[aiosqlite.Row]:
        cur = await self.conn.execute(
            "SELECT user_id, xp, wins, losses FROM military WHERE guild_id = ? AND xp > 0 "
            "ORDER BY xp DESC, wins DESC LIMIT ?",
            (guild_id, limit),
        )
        return list(await cur.fetchall())